var client;

// This is start of the code
$(document).ready(function () {
  $("#view1").show();
  app.initialized().then((function (_client) {
    client = _client
    renderText()
  }))
});

function renderText() {
  // In the html file we have defined a submit button. On click of that button "submitform" function will get called
  $("#submit").off().on('click', {}, submitform);
}

function submitform() {
 // First we will check whether the email and password field have some data inputed or not. If not throw error
 // Then we will authorize the data.
 // Else we are good to go
  var email= $("#email").val();
  var password= $("#password").val();
  if(!email || !password){
    showNotify("danger","Please enter the credentials.")
  }
  else if(email!= "abc@example.com" || password!="Test@123"){
    showNotify("danger","Wrong credentials. Please try again.")
  } 
  else {
    renderCustomerDataTable();
    $("#view2").show();
    $("#view1").hide();
  }
}

function renderCustomerDataTable() {
  /* We have used dummy datas instead of APIS(Because I am running short of time).
  Dummy datas are present in "app/datas/customerData.js"
   Design of dummy data= [{
      multiple customers present inside this array: each customer have multiple orders
  }] 

  So we will show all the customers in tabular format and will make the email ids clickable. 
  On click of the emailid the respective customers details will get opened in modal.
  */
  var columnNames = [
    { data: "email", name: "Email", title: "Email", width: "34%", "className": "emailClass" },
    { data: "first_name", name: "First Name", title: "First Name", width: "33%" },
    { data: "last_name", name: "Last Name", title: "Last Name", width: "33%" },
  ];
  var table= $('#customerTable').DataTable({
    data: customerData,
    columns: columnNames,
    "paging": true,
    "info": false,
    "language": {
      "emptyTable": "No data available"
    }
  })
  $('#customerTable thead th').css({ 'color': 'black', "text-decoration": "none" });
  $('#customerTable').on('click', 'td.emailClass', function () {
    client.interface.trigger("showModal", {
      title: "Customer Details",
      template: "customerDetails/customerDetail.html",
      data: table.row( this ).data()
    })
  });
}

function showNotify(type, message) {
  client.interface.trigger("showNotify", {
    type: type,
    message: message
  })
}