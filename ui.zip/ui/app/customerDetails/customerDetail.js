var client;
$(document).ready(function () {
    $("#view1").show();
    app.initialized().then((function (_client) {
        client = _client
        Promise.all([
            client.instance.context()
        ]).then((resArr) => {
            $("#spinner").show();
            /** Will wait for 2seconds and then render the tab to make the screen a little more interesting. */
            setTimeout(function () {
                console.log("Executed after 1 second");
                renderData(resArr[0].data)
            }, 2000);
        })
    }))
});

function renderData(resArr) {
    $("#spinner").hide();
    $("#details_tab").show();
    /** From here we will divide our all datas into two parts. customer details and customer order details
     * Will show customer details in an accordion
     * and customer order details in a data table
     */
    renderCustomerAccordion(resArr);
    renderCustomerOrders(resArr);
}

function renderCustomerAccordion(resArr) {
    /**
     * We have used fw crayons to render accordion. Below we have appended the according template in 
     * a div. Then for accordion body we have beautified our datas in left template and right template.
     */
    var data = renderCustomerAccordionTemplate(resArr)
    $("#customer_accordion").append(`
        <fw-accordion>
            <fw-accordion-title>Customer Info</fw-accordion-title>
            <fw-accordion-body>
                ${data}
            </fw-accordion-body>
        </fw-accordion>
    `)
}

function renderCustomerAccordionTemplate(data) {
    return `
    <div style="display:flex;">
        <div>
            <div style="display: flex;">
                    <p><b style="text-align: left;margin-left:5px;">First Name:</b></p>
                    <p style="margin-left: 10px;"> ${data.first_name}</p>
            </div>
            <div style="display: flex;">
                <p><b style="text-align: left;margin-left:5px;">Zip:</b></p>
                <p style="margin-left: 10px;"> ${data.zip}</p>
            </div>
            <div style="display: flex;">
                <p><b style="text-align: left;margin-left:5px;">Phone1:</b></p>
                <p style="margin-left: 10px;"> ${data.phone1}</p>
            </div>
            <div style="display: flex;">
                <p><b style="text-align: left;margin-left:5px;">County:</b></p>
                <p style="margin-left: 10px;"> ${data.country}</p>
            </div>
            <div style="display: flex;">
                <p><b style="text-align: left;margin-left:5px;">Address:</b></p>
                <p style="margin-left: 10px;"> ${data.address}</p>
            </div>
            <div style="display: flex;">
                <p><b style="text-align: left;margin-left:5px;">Email:</b></p>
                <p style="margin-left: 10px;"> ${data.email}</p>
            </div>
        </div>
        <div style="
        margin-left: -45px;
        margin-top: 6px;">
            <div style="display: flex;">
                <p><b style="text-align: right;margin-left:90px;">Last Name: </b></p>
                <p style="margin-left: 10px;"> ${data.last_name}</p>
            </div>
            <div style="display: flex;">
                <p><b style="text-align: right;margin-left:90px;">phone2: </b></p>
                <p style="margin-left: 10px;"> ${data.phone2}</p>
            </div>
            <div style="display: flex;">
                <p><b style="text-align: right;margin-left:90px;">State: </b></p>
                <p style="margin-left: 10px;"> ${data.state}</p>
            </div>
            <div style="display: flex;">
                <p><b style="text-align: right;margin-left:90px;">City: </b></p>
                <p style="margin-left: 10px;"> ${data.city}</p>
            </div>
        </div>
    </div>
    `
}

function renderCustomerOrders(resArr){
    /**
     * Below are the code for datatable.
     * in the first table row we have added a plus icon.
     * By default we will show "item Total" and "Status" in the table. Onclick of the plus icon, we will show other order 
     * related details in the sub table
     */
    var columnNames = [
        { data: null, "className":"details-control","orderable": false, "defaultContent":"",width:"10%" },
        { data: "item_totals", name: "Item Total", title: "Item Total", width: "45%" },
        { data: "status", name: "Status", title: "Status", width: "45%" },
      ];
      var table= $('#customerOrderTable').DataTable({
        data: resArr.CustomerOrders,
        columns: columnNames,
        "columnDefs": [
            {
                "render": function () {
                    return `<fw-icon name="plus" color="green" size=15 ></fw-icon>`
                },
                "targets": 0
            },
        ],
        "paging": false,
        "info": false,
        "language": {
          "emptyTable": "No data available"
        }
      })
/**
 * Below code is to minimize maximize subrows.
 */
      $('#customerOrderTable tbody').off().on("click", 'td.details-control',function() {
        var tr= $(this).closest("tr");
        var row= table.row(tr);
        if(row.child.isShown()) {
            row.child.hide();
            tr.removeClass('shown');
        } else {
            row.child(subRows(row.data())).show();
            tr.addClass('shown');
        }
      })
}
/**
 * Sub Row template below
 */
function subRows(data) {
    return '<table cellpadding="4" cellspacing="0" border="0" style="padding-left:50px;"'+
    '<tr>' +
        '<td class="attName odd">Status</td>'+
        '<td class="actualData" colspan="2">'+data.status+'</td>'+
        '<td class="attName odd">Item Total</td>'+
        '<td class="actualData" colspan="2">'+data.item_total+'</td>'+
    '</tr>' +
    '<tr>' +
        '<td class="attName odd">Total Amount</td>'+
        '<td class="actualData" colspan="2">'+data.total_amount+'</td>'+
        '<td class="attName odd">Order Tome</td>'+
        '<td class="actualData" colspan="2">'+data.createdAt+'</td>'+
    '</tr>' +
    '<tr>' +
        '<td class="attName odd">Billing address</td>'+
        '<td class="actualData" colspan="2">'+data.billing_address+'</td>'+
        '<td class="attName odd">Shipping address</td>'+
        '<td class="actualData" colspan="2">'+data.shipping_address+'</td>'+
    '</tr>' +
    '</table>' 
}
