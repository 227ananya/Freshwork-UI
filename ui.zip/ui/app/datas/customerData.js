var customerData= [
        {
            "uuid": "032eaa3b-3260-447c-8dd6-bd0de2ee1891",
            "first_name": "Arlette",
            "last_name": "Honeywell",
            "company_name": "Smc Inc",
            "address": "11279 Loytan St",
            "city": "Jacksonville",
            "county": "Duval",
            "state": "FL",
            "zip": 32254,
            "phone1": "904-775-4480",
            "phone2": "904-514-9918",
            "email": "ahoneywell@honeywell.com",
            "web": "http://www.smcinc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "4c296ced-57d5-4104-8875-8a031b81e77a",
                    "customer_uuid": "032eaa3b-3260-447c-8dd6-bd0de2ee1891",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "63",
                    "total_amount": "48869",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "38e7e820-fa74-4293-9867-fe1121dda6e0",
                            "order_uuid": "4c296ced-57d5-4104-8875-8a031b81e77a",
                            "item_name": "Item4",
                            "item_quantity": "26",
                            "price": "70427",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "77ec1170-27c3-47a0-9f5a-10603d1b5ef2",
                            "order_uuid": "4c296ced-57d5-4104-8875-8a031b81e77a",
                            "item_name": "Item2",
                            "item_quantity": "56",
                            "price": "22404",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                },
                {
                    "uuid": "4c296ced-57d5-4104-8875-8a031b81e77a",
                    "customer_uuid": "032eaa3b-3260-447c-8dd6-bd0de2ee1891",
                    "shipping_address": "44421 Davis Wells,24569",
                    "billing_address": "4444 Davis Wells,24569",
                    "status": "PENDING",
                    "item_totals": "2",
                    "total_amount": "50",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "38e7e820-fa74-4293-9867-fe1121dda6e0",
                            "order_uuid": "4c296ced-57d5-4104-8875-8a031b81e77a",
                            "item_name": "Item4",
                            "item_quantity": "26",
                            "price": "70427",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "77ec1170-27c3-47a0-9f5a-10603d1b5ef2",
                            "order_uuid": "4c296ced-57d5-4104-8875-8a031b81e77a",
                            "item_name": "Item2",
                            "item_quantity": "56",
                            "price": "22404",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                },
                {
                    "uuid": "4c296ced-57d5-4104-8875-8a031b81e77a",
                    "customer_uuid": "032eaa3b-3260-447c-8dd6-bd0de2ee1891",
                    "shipping_address": "123333 Davis Wells,24569",
                    "billing_address": "12333 Davis Wells,24569",
                    "status": "Failed",
                    "item_totals": "24",
                    "total_amount": "123333",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "38e7e820-fa74-4293-9867-fe1121dda6e0",
                            "order_uuid": "4c296ced-57d5-4104-8875-8a031b81e77a",
                            "item_name": "Item4",
                            "item_quantity": "26",
                            "price": "70427",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "77ec1170-27c3-47a0-9f5a-10603d1b5ef2",
                            "order_uuid": "4c296ced-57d5-4104-8875-8a031b81e77a",
                            "item_name": "Item2",
                            "item_quantity": "56",
                            "price": "22404",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "1092fa89-5880-4c8f-b6f2-52d8a89b0b12",
            "first_name": "Ernie",
            "last_name": "Stenseth",
            "company_name": "Knwz Newsradio",
            "address": "45 E Liberty St",
            "city": "Ridgefield Park",
            "county": "Bergen",
            "state": "NJ",
            "zip": 7660,
            "phone1": "201-709-6245",
            "phone2": "201-387-9093",
            "email": "ernie_stenseth@aol.com",
            "web": "http://www.knwznewsradio.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "8e481c2b-ebcb-46da-b8cb-4b8a941f55c5",
                    "customer_uuid": "1092fa89-5880-4c8f-b6f2-52d8a89b0b12",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "86",
                    "total_amount": "20605",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "6326712e-b325-4efd-bdba-6017c05a1970",
                            "order_uuid": "8e481c2b-ebcb-46da-b8cb-4b8a941f55c5",
                            "item_name": "Item4",
                            "item_quantity": "12",
                            "price": "12626",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "d57bba51-d356-4f9a-9f23-c2af60816c50",
                            "order_uuid": "8e481c2b-ebcb-46da-b8cb-4b8a941f55c5",
                            "item_name": "Item9",
                            "item_quantity": "34",
                            "price": "91930",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "120cff23-9e3c-4d2d-b5b2-f18deeb0f27d",
            "first_name": "Malinda",
            "last_name": "Hochard",
            "company_name": "Logan Memorial Hospital",
            "address": "55 Riverside Ave",
            "city": "Indianapolis",
            "county": "Marion",
            "state": "IN",
            "zip": 46202,
            "phone1": "317-722-5066",
            "phone2": "317-472-2412",
            "email": "malinda.hochard@yahoo.com",
            "web": "http://www.loganmemorialhospital.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "55f51f24-a93b-4b7c-a1ef-068aa800ca3c",
                    "customer_uuid": "120cff23-9e3c-4d2d-b5b2-f18deeb0f27d",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "29",
                    "total_amount": "12009",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "1a6a7816-afcb-4d68-aa52-27060276f077",
                            "order_uuid": "55f51f24-a93b-4b7c-a1ef-068aa800ca3c",
                            "item_name": "Item4",
                            "item_quantity": "29",
                            "price": "17731",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "7f7dbe14-44fb-466d-88ba-a32fb286b315",
                            "order_uuid": "55f51f24-a93b-4b7c-a1ef-068aa800ca3c",
                            "item_name": "Item2",
                            "item_quantity": "83",
                            "price": "33752",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "16157304-387a-41e6-b56a-262d455024af",
            "first_name": "Kanisha",
            "last_name": "Waycott",
            "company_name": "Schroer, Gene E Esq",
            "address": "5 Tomahawk Dr",
            "city": "Los Angeles",
            "county": "Los Angeles",
            "state": "CA",
            "zip": 90006,
            "phone1": "323-453-2780",
            "phone2": "323-315-7314",
            "email": "kanisha_waycott@yahoo.com",
            "web": "http://www.schroergeneeesq.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "a2e0337a-9534-4a28-b386-4e2bda343b36",
                    "customer_uuid": "16157304-387a-41e6-b56a-262d455024af",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "58",
                    "total_amount": "82183",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "0af259e5-5ee8-410e-8437-00f9a0963957",
                            "order_uuid": "a2e0337a-9534-4a28-b386-4e2bda343b36",
                            "item_name": "Item8",
                            "item_quantity": "100",
                            "price": "2729",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "a1bdc43a-4fc7-46d3-80e3-0b835ed8d4a8",
                            "order_uuid": "a2e0337a-9534-4a28-b386-4e2bda343b36",
                            "item_name": "Item3",
                            "item_quantity": "32",
                            "price": "34125",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "1b341121-b870-4fa9-abce-93ce6d4a5231",
            "first_name": "Chanel",
            "last_name": "Caudy",
            "company_name": "Professional Image Inc",
            "address": "86 Nw 66th St #8673",
            "city": "Shawnee",
            "county": "Johnson",
            "state": "KS",
            "zip": 66218,
            "phone1": "913-388-2079",
            "phone2": "913-899-1103",
            "email": "chanel.caudy@caudy.org",
            "web": "http://www.professionalimageinc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "eaeb7aa7-352f-436b-9980-c14763eec2d7",
                    "customer_uuid": "1b341121-b870-4fa9-abce-93ce6d4a5231",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "55",
                    "total_amount": "18891",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "321aeb62-bd78-4484-9269-8589e20ef6d5",
                            "order_uuid": "eaeb7aa7-352f-436b-9980-c14763eec2d7",
                            "item_name": "Item8",
                            "item_quantity": "72",
                            "price": "5209",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "b40fffb3-efb3-4cfc-bda1-fd896517515b",
                            "order_uuid": "eaeb7aa7-352f-436b-9980-c14763eec2d7",
                            "item_name": "Item9",
                            "item_quantity": "93",
                            "price": "77773",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "1c2dce89-8f1a-438c-b0a5-c2c435ac99a5",
            "first_name": "Lavera",
            "last_name": "Perin",
            "company_name": "Abc Enterprises Inc",
            "address": "678 3rd Ave",
            "city": "Miami",
            "county": "Miami-Dade",
            "state": "FL",
            "zip": 33196,
            "phone1": "305-606-7291",
            "phone2": "305-995-2078",
            "email": "lperin@perin.org",
            "web": "http://www.abcenterprisesinc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "afd73cd2-31fa-4c33-bf5b-9437c19913dc",
                    "customer_uuid": "1c2dce89-8f1a-438c-b0a5-c2c435ac99a5",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "68",
                    "total_amount": "42489",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "123824bc-232a-4305-b8aa-d95491bc1a22",
                            "order_uuid": "afd73cd2-31fa-4c33-bf5b-9437c19913dc",
                            "item_name": "Item5",
                            "item_quantity": "67",
                            "price": "80600",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "37c06461-2854-435c-bdac-09aa02b54ef0",
                            "order_uuid": "afd73cd2-31fa-4c33-bf5b-9437c19913dc",
                            "item_name": "Item7",
                            "item_quantity": "2",
                            "price": "81984",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "23335047-2c65-4802-b51e-44ed56f5d07f",
            "first_name": "Danica",
            "last_name": "Bruschke",
            "company_name": "Stevens, Charles T",
            "address": "840 15th Ave",
            "city": "Waco",
            "county": "McLennan",
            "state": "TX",
            "zip": 76708,
            "phone1": "254-782-8569",
            "phone2": "254-205-1422",
            "email": "danica_bruschke@gmail.com",
            "web": "http://www.stevenscharlest.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "4c3c3ae5-d605-4d13-918c-d2d77b3dbfa9",
                    "customer_uuid": "23335047-2c65-4802-b51e-44ed56f5d07f",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "91",
                    "total_amount": "50283",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "31498489-99ca-4043-923d-4847b3bd7f24",
                            "order_uuid": "4c3c3ae5-d605-4d13-918c-d2d77b3dbfa9",
                            "item_name": "Item4",
                            "item_quantity": "70",
                            "price": "35841",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "dbb19857-07ab-4c24-8cb3-4e83a014fcf1",
                            "order_uuid": "4c3c3ae5-d605-4d13-918c-d2d77b3dbfa9",
                            "item_name": "Item3",
                            "item_quantity": "16",
                            "price": "31658",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "23435b30-59cf-40b0-aa2c-5009614ac0ae",
            "first_name": "Sabra",
            "last_name": "Uyetake",
            "company_name": "Lowy Limousine Service",
            "address": "98839 Hawthorne Blvd #6101",
            "city": "Columbia",
            "county": "Richland",
            "state": "SC",
            "zip": 29201,
            "phone1": "803-925-5213",
            "phone2": "803-681-3678",
            "email": "sabra@uyetake.org",
            "web": "http://www.lowylimousineservice.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "50028046-1023-4e38-99b2-a132d92357f3",
                    "customer_uuid": "23435b30-59cf-40b0-aa2c-5009614ac0ae",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "55",
                    "total_amount": "22135",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "adb4771a-fdbd-482e-8c15-26c37f7c2c3b",
                            "order_uuid": "50028046-1023-4e38-99b2-a132d92357f3",
                            "item_name": "Item5",
                            "item_quantity": "40",
                            "price": "17080",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "d82ec364-1882-4ba0-9385-cb57b8c541b7",
                            "order_uuid": "50028046-1023-4e38-99b2-a132d92357f3",
                            "item_name": "Item3",
                            "item_quantity": "73",
                            "price": "39468",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "24624b57-48b2-4619-8b25-dd530e1c6a04",
            "first_name": "Josephine",
            "last_name": "Darakjy",
            "company_name": "Chanay, Jeffrey A Esq",
            "address": "4 B Blue Ridge Blvd",
            "city": "Brighton",
            "county": "Livingston",
            "state": "MI",
            "zip": 48116,
            "phone1": "810-292-9388",
            "phone2": "810-374-9840",
            "email": "josephine_darakjy@darakjy.org",
            "web": "http://www.chanayjeffreyaesq.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "936699a6-dfb7-43fc-b1b6-326803794c88",
                    "customer_uuid": "24624b57-48b2-4619-8b25-dd530e1c6a04",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "29",
                    "total_amount": "56039",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "0e96ab66-fd40-4cdb-9e97-9bb2fba17856",
                            "order_uuid": "936699a6-dfb7-43fc-b1b6-326803794c88",
                            "item_name": "Item7",
                            "item_quantity": "72",
                            "price": "3850",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "6c5b7fe2-4615-4cab-af19-cc7fdb4247df",
                            "order_uuid": "936699a6-dfb7-43fc-b1b6-326803794c88",
                            "item_name": "Item5",
                            "item_quantity": "21",
                            "price": "63034",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "24a6d8de-a9ee-491c-bf15-698274ff22e1",
            "first_name": "Marjory",
            "last_name": "Mastella",
            "company_name": "Vicon Corporation",
            "address": "71 San Mateo Ave",
            "city": "Wayne",
            "county": "Delaware",
            "state": "PA",
            "zip": 19087,
            "phone1": "610-814-5533",
            "phone2": "610-379-7125",
            "email": "mmastella@mastella.com",
            "web": "http://www.viconcorporation.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "267f74b8-ca06-4495-9870-98a510874b3f",
                    "customer_uuid": "24a6d8de-a9ee-491c-bf15-698274ff22e1",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "37",
                    "total_amount": "63882",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "416b02b0-abd8-410a-915b-4bad6a68f0d1",
                            "order_uuid": "267f74b8-ca06-4495-9870-98a510874b3f",
                            "item_name": "Item4",
                            "item_quantity": "72",
                            "price": "73301",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "d75ba57d-bbcd-4991-961d-10364ae89728",
                            "order_uuid": "267f74b8-ca06-4495-9870-98a510874b3f",
                            "item_name": "Item7",
                            "item_quantity": "56",
                            "price": "35871",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "2705d225-664a-4ff3-a2da-0b43f004d889",
            "first_name": "Karl",
            "last_name": "Klonowski",
            "company_name": "Rossi, Michael M",
            "address": "76 Brooks St #9",
            "city": "Flemington",
            "county": "Hunterdon",
            "state": "NJ",
            "zip": 8822,
            "phone1": "908-877-6135",
            "phone2": "908-470-4661",
            "email": "karl_klonowski@yahoo.com",
            "web": "http://www.rossimichaelm.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "1078e1ea-8c4c-49bf-aa8a-3f4f8ee08e81",
                    "customer_uuid": "2705d225-664a-4ff3-a2da-0b43f004d889",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "20",
                    "total_amount": "86210",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "7bb13efc-c324-4d79-af16-0c9676769e62",
                            "order_uuid": "1078e1ea-8c4c-49bf-aa8a-3f4f8ee08e81",
                            "item_name": "Item8",
                            "item_quantity": "12",
                            "price": "44322",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "b48a5b9c-8e0d-4ac2-aa3e-b639301e0eba",
                            "order_uuid": "1078e1ea-8c4c-49bf-aa8a-3f4f8ee08e81",
                            "item_name": "Item8",
                            "item_quantity": "80",
                            "price": "86247",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "27642093-0cec-47f5-bb33-9a4b1a1ce60a",
            "first_name": "Micaela",
            "last_name": "Rhymes",
            "company_name": "H Lee Leonard Attorney At Law",
            "address": "20932 Hedley St",
            "city": "Concord",
            "county": "Contra Costa",
            "state": "CA",
            "zip": 94520,
            "phone1": "925-647-3298",
            "phone2": "925-522-7798",
            "email": "micaela_rhymes@gmail.com",
            "web": "http://www.hleeleonardattorneyatlaw.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "e0ad9622-0ef1-46c2-a4b4-57bbce905225",
                    "customer_uuid": "27642093-0cec-47f5-bb33-9a4b1a1ce60a",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "67",
                    "total_amount": "17845",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "1fc6fb5d-ed52-441a-8aa5-534fa5c8929f",
                            "order_uuid": "e0ad9622-0ef1-46c2-a4b4-57bbce905225",
                            "item_name": "Item5",
                            "item_quantity": "53",
                            "price": "50822",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "f8c0c833-62dd-46b6-b3c4-45f7f799b90b",
                            "order_uuid": "e0ad9622-0ef1-46c2-a4b4-57bbce905225",
                            "item_name": "Item5",
                            "item_quantity": "79",
                            "price": "66667",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "2962a78a-571d-431a-a22d-c8be880e50ae",
            "first_name": "Cammy",
            "last_name": "Albares",
            "company_name": "Rousseaux, Michael Esq",
            "address": "56 E Morehead St",
            "city": "Laredo",
            "county": "Webb",
            "state": "TX",
            "zip": 78045,
            "phone1": "956-537-6195",
            "phone2": "956-841-7216",
            "email": "calbares@gmail.com",
            "web": "http://www.rousseauxmichaelesq.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "b6c7d450-0fe4-4a2d-a5cf-87557135cad4",
                    "customer_uuid": "2962a78a-571d-431a-a22d-c8be880e50ae",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "61",
                    "total_amount": "22245",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "b5f10f32-19b9-4411-940a-346a7eab480f",
                            "order_uuid": "b6c7d450-0fe4-4a2d-a5cf-87557135cad4",
                            "item_name": "Item2",
                            "item_quantity": "37",
                            "price": "48120",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "fde0462b-b6cf-49c7-b253-7f761a1c0d48",
                            "order_uuid": "b6c7d450-0fe4-4a2d-a5cf-87557135cad4",
                            "item_name": "Item10",
                            "item_quantity": "73",
                            "price": "41506",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "296c733e-4ea2-4d69-b99c-4ef5508ade57",
            "first_name": "Yuki",
            "last_name": "Whobrey",
            "company_name": "Farmers Insurance Group",
            "address": "1 State Route 27",
            "city": "Taylor",
            "county": "Wayne",
            "state": "MI",
            "zip": 48180,
            "phone1": "313-288-7937",
            "phone2": "313-341-4470",
            "email": "yuki_whobrey@aol.com",
            "web": "http://www.farmersinsurancegroup.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "73d62cf0-356d-4907-9d58-aa5e65943671",
                    "customer_uuid": "296c733e-4ea2-4d69-b99c-4ef5508ade57",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "34",
                    "total_amount": "51720",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "7634dee8-73ca-499e-be0b-321bf276464b",
                            "order_uuid": "73d62cf0-356d-4907-9d58-aa5e65943671",
                            "item_name": "Item7",
                            "item_quantity": "37",
                            "price": "99389",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "c934065e-4553-48bc-bddb-a8ceac23abd4",
                            "order_uuid": "73d62cf0-356d-4907-9d58-aa5e65943671",
                            "item_name": "Item9",
                            "item_quantity": "72",
                            "price": "78340",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "2de207fa-4362-4b90-8779-1a703532531d",
            "first_name": "Solange",
            "last_name": "Shinko",
            "company_name": "Mosocco, Ronald A",
            "address": "426 Wolf St",
            "city": "Metairie",
            "county": "Jefferson",
            "state": "LA",
            "zip": 70002,
            "phone1": "504-979-9175",
            "phone2": "504-265-8174",
            "email": "solange@shinko.com",
            "web": "http://www.mosoccoronalda.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "6aa7c661-1ebd-4fec-8857-7ea8f6dce242",
                    "customer_uuid": "2de207fa-4362-4b90-8779-1a703532531d",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "14",
                    "total_amount": "13106",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "5b613598-ae39-4b44-86af-a626f4195557",
                            "order_uuid": "6aa7c661-1ebd-4fec-8857-7ea8f6dce242",
                            "item_name": "Item6",
                            "item_quantity": "97",
                            "price": "42141",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "dcf8b22d-b0d5-4bc8-b833-4a379e32d331",
                            "order_uuid": "6aa7c661-1ebd-4fec-8857-7ea8f6dce242",
                            "item_name": "Item8",
                            "item_quantity": "23",
                            "price": "68936",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "2e6c8a9a-b463-42e6-89aa-087e2a4e36d0",
            "first_name": "Tyra",
            "last_name": "Shields",
            "company_name": "Assink, Anne H Esq",
            "address": "3 Fort Worth Ave",
            "city": "Philadelphia",
            "county": "Philadelphia",
            "state": "PA",
            "zip": 19106,
            "phone1": "215-255-1641",
            "phone2": "215-228-8264",
            "email": "tshields@gmail.com",
            "web": "http://www.assinkannehesq.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "db154ec8-c6f4-442e-9a5e-9f62f729e193",
                    "customer_uuid": "2e6c8a9a-b463-42e6-89aa-087e2a4e36d0",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "48",
                    "total_amount": "51093",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "0393f040-fab9-41c1-999f-e91a66253d62",
                            "order_uuid": "db154ec8-c6f4-442e-9a5e-9f62f729e193",
                            "item_name": "Item6",
                            "item_quantity": "79",
                            "price": "15370",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "b2892a08-1e2d-4beb-b16b-7def4d7357e4",
                            "order_uuid": "db154ec8-c6f4-442e-9a5e-9f62f729e193",
                            "item_name": "Item1",
                            "item_quantity": "89",
                            "price": "56084",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "320deac1-8553-4569-bf0c-bf6dfeed44db",
            "first_name": "Tawna",
            "last_name": "Buvens",
            "company_name": "H H H Enterprises Inc",
            "address": "3305 Nabell Ave #679",
            "city": "New York",
            "county": "New York",
            "state": "NY",
            "zip": 10009,
            "phone1": "212-674-9610",
            "phone2": "212-462-9157",
            "email": "tawna@gmail.com",
            "web": "http://www.hhhenterprisesinc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "a5dc66ba-0076-41ef-93db-b5cabfce171c",
                    "customer_uuid": "320deac1-8553-4569-bf0c-bf6dfeed44db",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "82",
                    "total_amount": "86342",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "808568bc-6513-4aa9-842e-3c1683b22b54",
                            "order_uuid": "a5dc66ba-0076-41ef-93db-b5cabfce171c",
                            "item_name": "Item5",
                            "item_quantity": "16",
                            "price": "34653",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "b365d395-4496-4a41-92d4-9376d52b55eb",
                            "order_uuid": "a5dc66ba-0076-41ef-93db-b5cabfce171c",
                            "item_name": "Item3",
                            "item_quantity": "33",
                            "price": "35190",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "329b8f77-6db3-48b4-8bb1-910ad2404308",
            "first_name": "Meaghan",
            "last_name": "Garufi",
            "company_name": "Bolton, Wilbur Esq",
            "address": "69734 E Carrillo St",
            "city": "Mc Minnville",
            "county": "Warren",
            "state": "TN",
            "zip": 37110,
            "phone1": "931-313-9635",
            "phone2": "931-235-7959",
            "email": "meaghan@hotmail.com",
            "web": "http://www.boltonwilburesq.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "422bbc14-b81a-4294-8b06-0e08e2cadb48",
                    "customer_uuid": "329b8f77-6db3-48b4-8bb1-910ad2404308",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "91",
                    "total_amount": "61530",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "0a55739c-6bd1-4eeb-830d-801ebacecbad",
                            "order_uuid": "422bbc14-b81a-4294-8b06-0e08e2cadb48",
                            "item_name": "Item10",
                            "item_quantity": "56",
                            "price": "86398",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "c7de3534-4ef3-4913-85d6-ca8cbd40eb9d",
                            "order_uuid": "422bbc14-b81a-4294-8b06-0e08e2cadb48",
                            "item_name": "Item4",
                            "item_quantity": "54",
                            "price": "67092",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "378ff6f3-2385-4acd-949f-a896d2b3ca28",
            "first_name": "Maurine",
            "last_name": "Yglesias",
            "company_name": "Schultz, Thomas C Md",
            "address": "59 Shady Ln #53",
            "city": "Milwaukee",
            "county": "Milwaukee",
            "state": "WI",
            "zip": 53214,
            "phone1": "414-748-1374",
            "phone2": "414-573-7719",
            "email": "maurine_yglesias@yglesias.com",
            "web": "http://www.schultzthomascmd.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "402e1133-e4b7-4824-9b44-3e0aac6501f5",
                    "customer_uuid": "378ff6f3-2385-4acd-949f-a896d2b3ca28",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "76",
                    "total_amount": "91077",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "acd828a4-c23d-4597-99e6-e445744f89c4",
                            "order_uuid": "402e1133-e4b7-4824-9b44-3e0aac6501f5",
                            "item_name": "Item6",
                            "item_quantity": "61",
                            "price": "16652",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "cd1399a7-563a-4ecb-a5b8-bbe03f5edc25",
                            "order_uuid": "402e1133-e4b7-4824-9b44-3e0aac6501f5",
                            "item_name": "Item4",
                            "item_quantity": "9",
                            "price": "22394",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "37a16b09-48d5-4da8-ad19-8f49c2af4e9c",
            "first_name": "Carma",
            "last_name": "Vanheusen",
            "company_name": "Springfield Div Oh Edison Co",
            "address": "68556 Central Hwy",
            "city": "San Leandro",
            "county": "Alameda",
            "state": "CA",
            "zip": 94577,
            "phone1": "510-503-7169",
            "phone2": "510-452-4835",
            "email": "carma@cox.net",
            "web": "http://www.springfielddivohedisonco.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "cad56e5d-79b9-440e-8487-5cb4863762f1",
                    "customer_uuid": "37a16b09-48d5-4da8-ad19-8f49c2af4e9c",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "95",
                    "total_amount": "85770",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "0c5f8e39-add2-4cfc-810c-8c9f5a7fb75e",
                            "order_uuid": "cad56e5d-79b9-440e-8487-5cb4863762f1",
                            "item_name": "Item1",
                            "item_quantity": "57",
                            "price": "68339",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "4ba057cb-795c-44d8-8d19-9121fdd5ef10",
                            "order_uuid": "cad56e5d-79b9-440e-8487-5cb4863762f1",
                            "item_name": "Item10",
                            "item_quantity": "83",
                            "price": "96543",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "408b569e-2d0e-4ee3-abfa-3af13a0f0c7c",
            "first_name": "Dyan",
            "last_name": "Oldroyd",
            "company_name": "International Eyelets Inc",
            "address": "7219 Woodfield Rd",
            "city": "Overland Park",
            "county": "Johnson",
            "state": "KS",
            "zip": 66204,
            "phone1": "913-413-4604",
            "phone2": "913-645-8918",
            "email": "doldroyd@aol.com",
            "web": "http://www.internationaleyeletsinc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "23703fd7-ba32-4f06-945a-0411eeb7c5d6",
                    "customer_uuid": "408b569e-2d0e-4ee3-abfa-3af13a0f0c7c",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "65",
                    "total_amount": "31735",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "86a547ca-b53d-4773-a833-90c036020dfc",
                            "order_uuid": "23703fd7-ba32-4f06-945a-0411eeb7c5d6",
                            "item_name": "Item6",
                            "item_quantity": "4",
                            "price": "44122",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "f8175ce6-81a9-434c-a5b2-3ba7d3f85aa5",
                            "order_uuid": "23703fd7-ba32-4f06-945a-0411eeb7c5d6",
                            "item_name": "Item8",
                            "item_quantity": "10",
                            "price": "61016",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "41962ded-5965-4230-a602-c6ac05502783",
            "first_name": "Kiley",
            "last_name": "Caldarera",
            "company_name": "Feiner Bros",
            "address": "25 E 75th St #69",
            "city": "Los Angeles",
            "county": "Los Angeles",
            "state": "CA",
            "zip": 90034,
            "phone1": "310-498-5651",
            "phone2": "310-254-3084",
            "email": "kiley.caldarera@aol.com",
            "web": "http://www.feinerbros.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "db8a3a19-1468-481e-bf99-249cb1199eac",
                    "customer_uuid": "41962ded-5965-4230-a602-c6ac05502783",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "4",
                    "total_amount": "20949",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "160868f2-03ed-49e3-8188-2f20a138e0e3",
                            "order_uuid": "db8a3a19-1468-481e-bf99-249cb1199eac",
                            "item_name": "Item3",
                            "item_quantity": "3",
                            "price": "48188",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "5fe995fd-1a6b-4c01-979b-3ede84cfbf62",
                            "order_uuid": "db8a3a19-1468-481e-bf99-249cb1199eac",
                            "item_name": "Item3",
                            "item_quantity": "31",
                            "price": "55459",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "44973386-849f-49d6-8307-e3bb8b3451bb",
            "first_name": "Timothy",
            "last_name": "Mulqueen",
            "company_name": "Saronix Nymph Products",
            "address": "44 W 4th St",
            "city": "Staten Island",
            "county": "Richmond",
            "state": "NY",
            "zip": 10309,
            "phone1": "718-332-6527",
            "phone2": "718-654-7063",
            "email": "timothy_mulqueen@mulqueen.org",
            "web": "http://www.saronixnymphproducts.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "84973add-70bb-459c-8c42-1476b09d823d",
                    "customer_uuid": "44973386-849f-49d6-8307-e3bb8b3451bb",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "71",
                    "total_amount": "89783",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "120edab6-09e8-40a2-8bf0-f55305d13159",
                            "order_uuid": "84973add-70bb-459c-8c42-1476b09d823d",
                            "item_name": "Item6",
                            "item_quantity": "35",
                            "price": "39252",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "3f3967e8-751f-4a1e-ae36-25f6a5ffd343",
                            "order_uuid": "84973add-70bb-459c-8c42-1476b09d823d",
                            "item_name": "Item4",
                            "item_quantity": "23",
                            "price": "81077",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "45b5d912-7bc2-448f-9901-ac6798a78b3f",
            "first_name": "Rozella",
            "last_name": "Ostrosky",
            "company_name": "Parkway Company",
            "address": "17 Morena Blvd",
            "city": "Camarillo",
            "county": "Ventura",
            "state": "CA",
            "zip": 93012,
            "phone1": "805-832-6163",
            "phone2": "805-609-1531",
            "email": "rozella.ostrosky@ostrosky.com",
            "web": "http://www.parkwaycompany.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "7e44d999-7271-4c92-97ae-d032c125c0cb",
                    "customer_uuid": "45b5d912-7bc2-448f-9901-ac6798a78b3f",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "31",
                    "total_amount": "72116",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "3592a46b-853c-4a83-b59d-1af3233f4d32",
                            "order_uuid": "7e44d999-7271-4c92-97ae-d032c125c0cb",
                            "item_name": "Item1",
                            "item_quantity": "90",
                            "price": "48597",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "ee2d6881-8ce7-4645-b937-3c2194c498e4",
                            "order_uuid": "7e44d999-7271-4c92-97ae-d032c125c0cb",
                            "item_name": "Item3",
                            "item_quantity": "93",
                            "price": "29865",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "468a4df8-7607-404c-8158-f2946959c01e",
            "first_name": "Alisha",
            "last_name": "Slusarski",
            "company_name": "Wtlz Power 107 Fm",
            "address": "3273 State St",
            "city": "Middlesex",
            "county": "Middlesex",
            "state": "NJ",
            "zip": 8846,
            "phone1": "732-658-3154",
            "phone2": "732-635-3453",
            "email": "alisha@slusarski.com",
            "web": "http://www.wtlzpowerfm.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "b5c3267a-ed4d-4ac8-a1df-971a9057d6ef",
                    "customer_uuid": "468a4df8-7607-404c-8158-f2946959c01e",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "55",
                    "total_amount": "79319",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "3b9272bc-97d2-4d4f-9d41-33f2f0bbe1a4",
                            "order_uuid": "b5c3267a-ed4d-4ac8-a1df-971a9057d6ef",
                            "item_name": "Item7",
                            "item_quantity": "81",
                            "price": "78718",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "9db08fb3-07e9-47ce-b209-2e0046942d5c",
                            "order_uuid": "b5c3267a-ed4d-4ac8-a1df-971a9057d6ef",
                            "item_name": "Item6",
                            "item_quantity": "40",
                            "price": "29364",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "472d58dd-055a-401f-b816-05f7c422a3ea",
            "first_name": "Jamal",
            "last_name": "Vanausdal",
            "company_name": "Hubbard, Bruce Esq",
            "address": "53075 Sw 152nd Ter #615",
            "city": "Monroe Township",
            "county": "Middlesex",
            "state": "NJ",
            "zip": 8831,
            "phone1": "732-234-1546",
            "phone2": "732-904-2931",
            "email": "jamal@vanausdal.org",
            "web": "http://www.hubbardbruceesq.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "3f717e54-48ea-40bd-98a6-3aaeb9bd1eca",
                    "customer_uuid": "472d58dd-055a-401f-b816-05f7c422a3ea",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "33",
                    "total_amount": "8199",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "46d106a3-a746-4c78-b707-4dc4befac8c6",
                            "order_uuid": "3f717e54-48ea-40bd-98a6-3aaeb9bd1eca",
                            "item_name": "Item8",
                            "item_quantity": "84",
                            "price": "9290",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "70b61a21-6b24-4845-a045-0d4793e1beac",
                            "order_uuid": "3f717e54-48ea-40bd-98a6-3aaeb9bd1eca",
                            "item_name": "Item9",
                            "item_quantity": "16",
                            "price": "3759",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "47b7c118-d1e4-4d51-b1ac-7ff883329a2c",
            "first_name": "Tammara",
            "last_name": "Wardrip",
            "company_name": "Jewel My Shop Inc",
            "address": "4800 Black Horse Pike",
            "city": "Burlingame",
            "county": "San Mateo",
            "state": "CA",
            "zip": 94010,
            "phone1": "650-803-1936",
            "phone2": "650-216-5075",
            "email": "twardrip@cox.net",
            "web": "http://www.jewelmyshopinc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "7bf9620e-0a8e-45e8-8e11-a334828c1a94",
                    "customer_uuid": "47b7c118-d1e4-4d51-b1ac-7ff883329a2c",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "98",
                    "total_amount": "33322",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "4062ab4d-3302-4a37-bd8b-7cb64ba541f0",
                            "order_uuid": "7bf9620e-0a8e-45e8-8e11-a334828c1a94",
                            "item_name": "Item10",
                            "item_quantity": "68",
                            "price": "82520",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "c24b3c30-a7ea-4994-b6ca-a7482f52e709",
                            "order_uuid": "7bf9620e-0a8e-45e8-8e11-a334828c1a94",
                            "item_name": "Item4",
                            "item_quantity": "71",
                            "price": "26549",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "47c1cbd3-a051-4492-ab6a-7f35a3a038fc",
            "first_name": "Devorah",
            "last_name": "Chickering",
            "company_name": "Garrison Ind",
            "address": "31 Douglas Blvd #950",
            "city": "Clovis",
            "county": "Curry",
            "state": "NM",
            "zip": 88101,
            "phone1": "505-975-8559",
            "phone2": "505-950-1763",
            "email": "devorah@hotmail.com",
            "web": "http://www.garrisonind.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "4e06a4ed-9a1b-4b0b-a579-67a0ce97895d",
                    "customer_uuid": "47c1cbd3-a051-4492-ab6a-7f35a3a038fc",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "8",
                    "total_amount": "78379",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "6a19f001-1bde-46be-bc06-f1d8fefd0c6e",
                            "order_uuid": "4e06a4ed-9a1b-4b0b-a579-67a0ce97895d",
                            "item_name": "Item7",
                            "item_quantity": "45",
                            "price": "98557",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "922edbe3-284f-47f6-bb93-bdee79422f2c",
                            "order_uuid": "4e06a4ed-9a1b-4b0b-a579-67a0ce97895d",
                            "item_name": "Item8",
                            "item_quantity": "3",
                            "price": "13777",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "498520d7-30ed-47bb-8d93-2b78820ab20e",
            "first_name": "Lorrie",
            "last_name": "Nestle",
            "company_name": "Ballard Spahr Andrews",
            "address": "39 S 7th St",
            "city": "Tullahoma",
            "county": "Coffee",
            "state": "TN",
            "zip": 37388,
            "phone1": "931-875-6644",
            "phone2": "931-303-6041",
            "email": "lnestle@hotmail.com",
            "web": "http://www.ballardspahrandrews.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "b9980f7d-1e50-4670-8210-2897e54fa05a",
                    "customer_uuid": "498520d7-30ed-47bb-8d93-2b78820ab20e",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "52",
                    "total_amount": "28774",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "af0559f8-6046-4b11-bdec-b9c550d652bc",
                            "order_uuid": "b9980f7d-1e50-4670-8210-2897e54fa05a",
                            "item_name": "Item3",
                            "item_quantity": "86",
                            "price": "41766",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "b76b669c-9736-4128-a860-08ba493f8973",
                            "order_uuid": "b9980f7d-1e50-4670-8210-2897e54fa05a",
                            "item_name": "Item3",
                            "item_quantity": "60",
                            "price": "11798",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "4a406de0-4ce2-4cb1-87c0-2b0740ea6a7d",
            "first_name": "Valentine",
            "last_name": "Gillian",
            "company_name": "Fbs Business Finance",
            "address": "775 W 17th St",
            "city": "San Antonio",
            "county": "Bexar",
            "state": "TX",
            "zip": 78204,
            "phone1": "210-812-9597",
            "phone2": "210-300-6244",
            "email": "valentine_gillian@gmail.com",
            "web": "http://www.fbsbusinessfinance.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "5be6247a-fba4-4156-8707-8274e0af65db",
                    "customer_uuid": "4a406de0-4ce2-4cb1-87c0-2b0740ea6a7d",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "100",
                    "total_amount": "98707",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "3fa5afa6-e9f2-494b-b028-c7043c1c243d",
                            "order_uuid": "5be6247a-fba4-4156-8707-8274e0af65db",
                            "item_name": "Item10",
                            "item_quantity": "21",
                            "price": "18444",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "dc2961f6-4102-4a7f-a2bc-a0890218f076",
                            "order_uuid": "5be6247a-fba4-4156-8707-8274e0af65db",
                            "item_name": "Item8",
                            "item_quantity": "61",
                            "price": "49191",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "4e0730c8-54d2-456f-9bd5-f1ec754a3795",
            "first_name": "Wilda",
            "last_name": "Giguere",
            "company_name": "Mclaughlin, Luther W Cpa",
            "address": "1747 Calle Amanecer #2",
            "city": "Anchorage",
            "county": "Anchorage",
            "state": "AK",
            "zip": 99501,
            "phone1": "907-870-5536",
            "phone2": "907-914-9482",
            "email": "wilda@cox.net",
            "web": "http://www.mclaughlinlutherwcpa.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "6992a2d5-cc56-4a96-a4af-55c4dd113558",
                    "customer_uuid": "4e0730c8-54d2-456f-9bd5-f1ec754a3795",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "87",
                    "total_amount": "48731",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "29c65c51-63fa-4c06-912c-8e62e3e7d32c",
                            "order_uuid": "6992a2d5-cc56-4a96-a4af-55c4dd113558",
                            "item_name": "Item9",
                            "item_quantity": "59",
                            "price": "77455",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "aea4f297-b442-462a-ae7f-825a5db9ad8e",
                            "order_uuid": "6992a2d5-cc56-4a96-a4af-55c4dd113558",
                            "item_name": "Item2",
                            "item_quantity": "82",
                            "price": "17362",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "4fac62da-9bfb-4f0e-8917-ebdb1caedc0d",
            "first_name": "Kallie",
            "last_name": "Blackwood",
            "company_name": "Rowley Schlimgen Inc",
            "address": "701 S Harrison Rd",
            "city": "San Francisco",
            "county": "San Francisco",
            "state": "CA",
            "zip": 94104,
            "phone1": "415-315-2761",
            "phone2": "415-604-7609",
            "email": "kallie.blackwood@gmail.com",
            "web": "http://www.rowleyschlimgeninc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "a35d3a31-bd2b-4811-ba43-a483289d9819",
                    "customer_uuid": "4fac62da-9bfb-4f0e-8917-ebdb1caedc0d",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "50",
                    "total_amount": "47636",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "0f6f7d6e-a218-4bb8-a80c-24301ea33217",
                            "order_uuid": "a35d3a31-bd2b-4811-ba43-a483289d9819",
                            "item_name": "Item3",
                            "item_quantity": "39",
                            "price": "62057",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "6f8fdda5-0c42-40ac-9bf9-409257100f6a",
                            "order_uuid": "a35d3a31-bd2b-4811-ba43-a483289d9819",
                            "item_name": "Item2",
                            "item_quantity": "10",
                            "price": "38254",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "524f8c90-2c5a-4abc-9d0c-9b0a77eeea71",
            "first_name": "Viva",
            "last_name": "Toelkes",
            "company_name": "Mark Iv Press Ltd",
            "address": "4284 Dorigo Ln",
            "city": "Chicago",
            "county": "Cook",
            "state": "IL",
            "zip": 60647,
            "phone1": "773-446-5569",
            "phone2": "773-352-3437",
            "email": "viva.toelkes@gmail.com",
            "web": "http://www.markivpressltd.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "cc4b8cba-f369-4e62-89b4-aa45f2cf62cb",
                    "customer_uuid": "524f8c90-2c5a-4abc-9d0c-9b0a77eeea71",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "56",
                    "total_amount": "88517",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "b0025782-5d9d-4525-b2c6-1873c317eadb",
                            "order_uuid": "cc4b8cba-f369-4e62-89b4-aa45f2cf62cb",
                            "item_name": "Item9",
                            "item_quantity": "54",
                            "price": "34959",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "efb8b9d7-7da0-4384-a0c5-152a25e9899a",
                            "order_uuid": "cc4b8cba-f369-4e62-89b4-aa45f2cf62cb",
                            "item_name": "Item4",
                            "item_quantity": "45",
                            "price": "43101",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "5519ae51-8378-4106-9deb-2ab58919d12c",
            "first_name": "Blair",
            "last_name": "Malet",
            "company_name": "Bollinger Mach Shp & Shipyard",
            "address": "209 Decker Dr",
            "city": "Philadelphia",
            "county": "Philadelphia",
            "state": "PA",
            "zip": 19132,
            "phone1": "215-907-9111",
            "phone2": "215-794-4519",
            "email": "bmalet@yahoo.com",
            "web": "http://www.bollingermachshpshipyard.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "a8c9abca-9424-49e0-ad33-807a26b9ae34",
                    "customer_uuid": "5519ae51-8378-4106-9deb-2ab58919d12c",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "35",
                    "total_amount": "25566",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "06b194b0-aa37-4b84-80d1-af9bdfb85a0d",
                            "order_uuid": "a8c9abca-9424-49e0-ad33-807a26b9ae34",
                            "item_name": "Item9",
                            "item_quantity": "82",
                            "price": "63232",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "26b5739c-7bea-4f22-b83f-6ec5eeef7c1b",
                            "order_uuid": "a8c9abca-9424-49e0-ad33-807a26b9ae34",
                            "item_name": "Item3",
                            "item_quantity": "63",
                            "price": "26441",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "594dc50e-272a-4283-94fd-085132fe7683",
            "first_name": "Shenika",
            "last_name": "Seewald",
            "company_name": "East Coast Marketing",
            "address": "4 Otis St",
            "city": "Van Nuys",
            "county": "Los Angeles",
            "state": "CA",
            "zip": 91405,
            "phone1": "818-423-4007",
            "phone2": "818-749-8650",
            "email": "shenika@gmail.com",
            "web": "http://www.eastcoastmarketing.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "e8ad4bf2-e558-4f07-bc46-943e2af484b0",
                    "customer_uuid": "594dc50e-272a-4283-94fd-085132fe7683",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "92",
                    "total_amount": "15733",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "28c6c3e7-cc0c-4741-afb7-b92a118c47fa",
                            "order_uuid": "e8ad4bf2-e558-4f07-bc46-943e2af484b0",
                            "item_name": "Item3",
                            "item_quantity": "17",
                            "price": "8213",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "46fd85f1-4869-4e6c-9945-70ccfe9b92b1",
                            "order_uuid": "e8ad4bf2-e558-4f07-bc46-943e2af484b0",
                            "item_name": "Item7",
                            "item_quantity": "22",
                            "price": "38525",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "5f13836a-8c45-4ef4-8f38-ff7a64f6a46e",
            "first_name": "Deeanna",
            "last_name": "Juhas",
            "company_name": "Healy, George W Iv",
            "address": "14302 Pennsylvania Ave",
            "city": "Huntingdon Valley",
            "county": "Montgomery",
            "state": "PA",
            "zip": 19006,
            "phone1": "215-211-9589",
            "phone2": "215-417-9563",
            "email": "deeanna_juhas@gmail.com",
            "web": "http://www.healygeorgewiv.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "2ea1bebd-8d3c-47e4-80a0-787fa99c35d8",
                    "customer_uuid": "5f13836a-8c45-4ef4-8f38-ff7a64f6a46e",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "78",
                    "total_amount": "409",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "d81f9159-eec8-468b-8b01-a01c8d42e302",
                            "order_uuid": "2ea1bebd-8d3c-47e4-80a0-787fa99c35d8",
                            "item_name": "Item5",
                            "item_quantity": "34",
                            "price": "21476",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "ec8af339-077d-4e84-83a1-32126321c2ea",
                            "order_uuid": "2ea1bebd-8d3c-47e4-80a0-787fa99c35d8",
                            "item_name": "Item2",
                            "item_quantity": "86",
                            "price": "11999",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "5fc22ac7-32e6-48cf-8e15-ca5530444ac2",
            "first_name": "Stephaine",
            "last_name": "Barfield",
            "company_name": "Beutelschies & Company",
            "address": "47154 Whipple Ave Nw",
            "city": "Gardena",
            "county": "Los Angeles",
            "state": "CA",
            "zip": 90247,
            "phone1": "310-774-7643",
            "phone2": "310-968-1219",
            "email": "stephaine@barfield.com",
            "web": "http://www.beutelschiescompany.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "9f8d3742-4776-4f79-b733-56ec891f8277",
                    "customer_uuid": "5fc22ac7-32e6-48cf-8e15-ca5530444ac2",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "86",
                    "total_amount": "20101",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "c9677913-e0e4-4f30-a310-88fb85ee4d5f",
                            "order_uuid": "9f8d3742-4776-4f79-b733-56ec891f8277",
                            "item_name": "Item5",
                            "item_quantity": "98",
                            "price": "80215",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "fdcb3a38-0c57-4c28-a6f4-f529c51c9595",
                            "order_uuid": "9f8d3742-4776-4f79-b733-56ec891f8277",
                            "item_name": "Item4",
                            "item_quantity": "71",
                            "price": "93001",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "5fc9124d-69fb-44a0-85e1-08f2737640be",
            "first_name": "Francine",
            "last_name": "Vocelka",
            "company_name": "Cascade Realty Advisors Inc",
            "address": "366 South Dr",
            "city": "Las Cruces",
            "county": "Dona Ana",
            "state": "NM",
            "zip": 88011,
            "phone1": "505-977-3911",
            "phone2": "505-335-5293",
            "email": "francine_vocelka@vocelka.com",
            "web": "http://www.cascaderealtyadvisorsinc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "68826327-bbda-4b4b-af37-51c3e906a940",
                    "customer_uuid": "5fc9124d-69fb-44a0-85e1-08f2737640be",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "70",
                    "total_amount": "12923",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "505b4647-438f-4276-a52d-eb2b176532e7",
                            "order_uuid": "68826327-bbda-4b4b-af37-51c3e906a940",
                            "item_name": "Item7",
                            "item_quantity": "36",
                            "price": "67426",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "8714fd36-cd3c-4008-a4ee-032879beb84a",
                            "order_uuid": "68826327-bbda-4b4b-af37-51c3e906a940",
                            "item_name": "Item6",
                            "item_quantity": "35",
                            "price": "69972",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "6b915d60-15c9-4917-9563-aedbd3c12714",
            "first_name": "Laurel",
            "last_name": "Reitler",
            "company_name": "Q A Service",
            "address": "6 Kains Ave",
            "city": "Baltimore",
            "county": "Baltimore City",
            "state": "MD",
            "zip": 21215,
            "phone1": "410-520-4832",
            "phone2": "410-957-6903",
            "email": "laurel_reitler@reitler.com",
            "web": "http://www.qaservice.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "965b21b1-e85f-484e-bb66-ac93cae40841",
                    "customer_uuid": "6b915d60-15c9-4917-9563-aedbd3c12714",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "72",
                    "total_amount": "51611",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "6e6def8a-99a2-4a09-8b3d-8bd086975f3b",
                            "order_uuid": "965b21b1-e85f-484e-bb66-ac93cae40841",
                            "item_name": "Item8",
                            "item_quantity": "82",
                            "price": "88295",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "85256a3e-878e-4a97-b452-50ee9145927b",
                            "order_uuid": "965b21b1-e85f-484e-bb66-ac93cae40841",
                            "item_name": "Item2",
                            "item_quantity": "5",
                            "price": "9184",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "6ea2d6e1-0851-458a-ae5e-2e5f537c6742",
            "first_name": "Leota",
            "last_name": "Dilliard",
            "company_name": "Commercial Press",
            "address": "7 W Jackson Blvd",
            "city": "San Jose",
            "county": "Santa Clara",
            "state": "CA",
            "zip": 95111,
            "phone1": "408-752-3500",
            "phone2": "408-813-1105",
            "email": "leota@hotmail.com",
            "web": "http://www.commercialpress.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "7e0ff3e0-4701-43bb-bf23-fe44a0c4ab7c",
                    "customer_uuid": "6ea2d6e1-0851-458a-ae5e-2e5f537c6742",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "69",
                    "total_amount": "96068",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "7c014624-1096-4bb7-a5c2-d1236dcbd0f8",
                            "order_uuid": "7e0ff3e0-4701-43bb-bf23-fe44a0c4ab7c",
                            "item_name": "Item6",
                            "item_quantity": "69",
                            "price": "23659",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "fee1223e-7dbf-4d12-ae3b-3e64f987356d",
                            "order_uuid": "7e0ff3e0-4701-43bb-bf23-fe44a0c4ab7c",
                            "item_name": "Item3",
                            "item_quantity": "55",
                            "price": "83978",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "6eb81ec6-d4e2-4a37-9e1d-6822c213d72e",
            "first_name": "Tonette",
            "last_name": "Wenner",
            "company_name": "Northwest Publishing",
            "address": "4545 Courthouse Rd",
            "city": "Westbury",
            "county": "Nassau",
            "state": "NY",
            "zip": 11590,
            "phone1": "516-968-6051",
            "phone2": "516-333-4861",
            "email": "twenner@aol.com",
            "web": "http://www.northwestpublishing.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "54bae0f1-6091-4195-a04c-36cf9a0d14c0",
                    "customer_uuid": "6eb81ec6-d4e2-4a37-9e1d-6822c213d72e",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "26",
                    "total_amount": "46980",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "7addf28d-de71-43ab-951f-3ce5678f5861",
                            "order_uuid": "54bae0f1-6091-4195-a04c-36cf9a0d14c0",
                            "item_name": "Item5",
                            "item_quantity": "61",
                            "price": "73425",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "8ff8c050-f4d1-4de1-a66a-4b467ffa2d33",
                            "order_uuid": "54bae0f1-6091-4195-a04c-36cf9a0d14c0",
                            "item_name": "Item8",
                            "item_quantity": "34",
                            "price": "2741",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "73014bfb-6cd6-4106-acc2-2ed9deaf51c5",
            "first_name": "Minna",
            "last_name": "Amigon",
            "company_name": "Dorl, James J Esq",
            "address": "2371 Jerrold Ave",
            "city": "Kulpsville",
            "county": "Montgomery",
            "state": "PA",
            "zip": 19443,
            "phone1": "215-874-1229",
            "phone2": "215-422-8694",
            "email": "minna_amigon@yahoo.com",
            "web": "http://www.dorljamesjesq.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "20fc0ba4-d87d-45ea-88e3-2a836f2cf2bb",
                    "customer_uuid": "73014bfb-6cd6-4106-acc2-2ed9deaf51c5",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "87",
                    "total_amount": "18316",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "21fc682e-ade7-4719-b086-241cae87b608",
                            "order_uuid": "20fc0ba4-d87d-45ea-88e3-2a836f2cf2bb",
                            "item_name": "Item4",
                            "item_quantity": "8",
                            "price": "69903",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "bd58d1e4-45c2-41ee-bd87-6882eca25e39",
                            "order_uuid": "20fc0ba4-d87d-45ea-88e3-2a836f2cf2bb",
                            "item_name": "Item1",
                            "item_quantity": "57",
                            "price": "78103",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "7c357c04-948e-47d3-ba63-22d31dffcfef",
            "first_name": "Maryann",
            "last_name": "Royster",
            "company_name": "Franklin, Peter L Esq",
            "address": "74 S Westgate St",
            "city": "Albany",
            "county": "Albany",
            "state": "NY",
            "zip": 12204,
            "phone1": "518-966-7987",
            "phone2": "518-448-8982",
            "email": "mroyster@royster.com",
            "web": "http://www.franklinpeterlesq.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "9b74448a-3881-46ab-a1a8-f6ee0cde282e",
                    "customer_uuid": "7c357c04-948e-47d3-ba63-22d31dffcfef",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "70",
                    "total_amount": "63673",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "059aacd2-2b26-4234-b3da-aee04436641f",
                            "order_uuid": "9b74448a-3881-46ab-a1a8-f6ee0cde282e",
                            "item_name": "Item9",
                            "item_quantity": "18",
                            "price": "87882",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "8cef4e6f-fbb3-44d7-8d9f-866fe15db00b",
                            "order_uuid": "9b74448a-3881-46ab-a1a8-f6ee0cde282e",
                            "item_name": "Item1",
                            "item_quantity": "8",
                            "price": "93133",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "80e6cb8c-1040-4adf-b487-da180dfa05b5",
            "first_name": "Lisha",
            "last_name": "Centini",
            "company_name": "Industrial Paper Shredders Inc",
            "address": "64 5th Ave #1153",
            "city": "Mc Lean",
            "county": "Fairfax",
            "state": "VA",
            "zip": 22102,
            "phone1": "703-235-3937",
            "phone2": "703-475-7568",
            "email": "lisha@centini.org",
            "web": "http://www.industrialpapershreddersinc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "5859bc2e-425a-47a0-b6ca-fffc6fa40fe5",
                    "customer_uuid": "80e6cb8c-1040-4adf-b487-da180dfa05b5",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "18",
                    "total_amount": "24343",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "b840b876-88cc-4176-ab5a-3685c78365aa",
                            "order_uuid": "5859bc2e-425a-47a0-b6ca-fffc6fa40fe5",
                            "item_name": "Item7",
                            "item_quantity": "18",
                            "price": "87403",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "d05fe5a2-13e2-4fff-ab4e-4882ea6d706f",
                            "order_uuid": "5859bc2e-425a-47a0-b6ca-fffc6fa40fe5",
                            "item_name": "Item3",
                            "item_quantity": "100",
                            "price": "68517",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "83e4e1ea-a505-4c67-9f61-a309eb85ae8f",
            "first_name": "Blondell",
            "last_name": "Pugh",
            "company_name": "Alpenlite Inc",
            "address": "201 Hawk Ct",
            "city": "Providence",
            "county": "Providence",
            "state": "RI",
            "zip": 2904,
            "phone1": "401-960-8259",
            "phone2": "401-300-8122",
            "email": "bpugh@aol.com",
            "web": "http://www.alpenliteinc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "1139a044-51cc-46a6-a1cf-31f76547950a",
                    "customer_uuid": "83e4e1ea-a505-4c67-9f61-a309eb85ae8f",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "88",
                    "total_amount": "97705",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "53c6f337-f092-4f24-854e-4c1e2bb797b5",
                            "order_uuid": "1139a044-51cc-46a6-a1cf-31f76547950a",
                            "item_name": "Item4",
                            "item_quantity": "94",
                            "price": "60870",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "c3b3dc82-2495-4022-8812-e65b55893d0c",
                            "order_uuid": "1139a044-51cc-46a6-a1cf-31f76547950a",
                            "item_name": "Item10",
                            "item_quantity": "66",
                            "price": "36100",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "888ba03b-9367-4d0e-912d-563134666df2",
            "first_name": "Elvera",
            "last_name": "Benimadho",
            "company_name": "Tree Musketeers",
            "address": "99385 Charity St #840",
            "city": "San Jose",
            "county": "Santa Clara",
            "state": "CA",
            "zip": 95110,
            "phone1": "408-703-8505",
            "phone2": "408-440-8447",
            "email": "elvera.benimadho@cox.net",
            "web": "http://www.treemusketeers.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "ddf9e93d-5abc-44d3-92d9-4af6de04d36d",
                    "customer_uuid": "888ba03b-9367-4d0e-912d-563134666df2",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "53",
                    "total_amount": "33908",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "b0eee51b-8b94-4ef0-a27b-4ffd6019738e",
                            "order_uuid": "ddf9e93d-5abc-44d3-92d9-4af6de04d36d",
                            "item_name": "Item8",
                            "item_quantity": "95",
                            "price": "44048",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "ceb38972-0993-4916-8db6-e2df84f2a23d",
                            "order_uuid": "ddf9e93d-5abc-44d3-92d9-4af6de04d36d",
                            "item_name": "Item2",
                            "item_quantity": "11",
                            "price": "65073",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "88c4ca01-36f6-432f-b0f2-1ec9417e38ec",
            "first_name": "Ezekiel",
            "last_name": "Chui",
            "company_name": "Sider, Donald C Esq",
            "address": "2 Cedar Ave #84",
            "city": "Easton",
            "county": "Talbot",
            "state": "MD",
            "zip": 21601,
            "phone1": "410-669-1642",
            "phone2": "410-235-8738",
            "email": "ezekiel@chui.com",
            "web": "http://www.siderdonaldcesq.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "e2421290-126d-4ec3-aa40-e278ffc7c439",
                    "customer_uuid": "88c4ca01-36f6-432f-b0f2-1ec9417e38ec",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "65",
                    "total_amount": "87525",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "4c985de8-0170-42fb-a0ea-71529083582d",
                            "order_uuid": "e2421290-126d-4ec3-aa40-e278ffc7c439",
                            "item_name": "Item3",
                            "item_quantity": "32",
                            "price": "1693",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "6cb2eb48-a4ec-4ccf-b286-bdb210381c1f",
                            "order_uuid": "e2421290-126d-4ec3-aa40-e278ffc7c439",
                            "item_name": "Item7",
                            "item_quantity": "67",
                            "price": "34623",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "8ee114b3-0399-455b-a152-05c0e0580f42",
            "first_name": "Johnetta",
            "last_name": "Abdallah",
            "company_name": "Forging Specialties",
            "address": "1088 Pinehurst St",
            "city": "Chapel Hill",
            "county": "Orange",
            "state": "NC",
            "zip": 27514,
            "phone1": "919-225-9345",
            "phone2": "919-715-3791",
            "email": "johnetta_abdallah@aol.com",
            "web": "http://www.forgingspecialties.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "f3f7fd65-5fa5-42ea-bf96-1b849dfbe745",
                    "customer_uuid": "8ee114b3-0399-455b-a152-05c0e0580f42",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "88",
                    "total_amount": "63658",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "992c6a49-1c49-4c37-91c6-376bcac4af29",
                            "order_uuid": "f3f7fd65-5fa5-42ea-bf96-1b849dfbe745",
                            "item_name": "Item5",
                            "item_quantity": "76",
                            "price": "47423",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "fe367585-7a18-4599-95cc-206691ed1978",
                            "order_uuid": "f3f7fd65-5fa5-42ea-bf96-1b849dfbe745",
                            "item_name": "Item7",
                            "item_quantity": "13",
                            "price": "31868",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "8f41b643-9b3d-4414-a699-449902137b9d",
            "first_name": "Abel",
            "last_name": "Maclead",
            "company_name": "Rangoni Of Florence",
            "address": "37275 St  Rt 17m M",
            "city": "Middle Island",
            "county": "Suffolk",
            "state": "NY",
            "zip": 11953,
            "phone1": "631-335-3414",
            "phone2": "631-677-3675",
            "email": "amaclead@gmail.com",
            "web": "http://www.rangoniofflorence.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "5096bab1-2884-4138-af33-f4b34f614f95",
                    "customer_uuid": "8f41b643-9b3d-4414-a699-449902137b9d",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "62",
                    "total_amount": "61858",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "4402c629-8c1f-4741-b894-70d7730e3911",
                            "order_uuid": "5096bab1-2884-4138-af33-f4b34f614f95",
                            "item_name": "Item6",
                            "item_quantity": "79",
                            "price": "79570",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "c3a2ba40-cf5d-4596-b3df-a9afdc80d33b",
                            "order_uuid": "5096bab1-2884-4138-af33-f4b34f614f95",
                            "item_name": "Item6",
                            "item_quantity": "45",
                            "price": "20164",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "8f790e98-5c30-49d0-850c-aaa43db17746",
            "first_name": "Art",
            "last_name": "Venere",
            "company_name": "Chemel, James L Cpa",
            "address": "8 W Cerritos Ave #54",
            "city": "Bridgeport",
            "county": "Gloucester",
            "state": "NJ",
            "zip": 8014,
            "phone1": "856-636-8749",
            "phone2": "856-264-4130",
            "email": "art@venere.org",
            "web": "http://www.chemeljameslcpa.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "b5aff589-dc86-4fdd-b830-c64cf3f77e59",
                    "customer_uuid": "8f790e98-5c30-49d0-850c-aaa43db17746",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "77",
                    "total_amount": "74113",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "7c2ecc91-0313-418e-9f5a-98f127f31333",
                            "order_uuid": "b5aff589-dc86-4fdd-b830-c64cf3f77e59",
                            "item_name": "Item8",
                            "item_quantity": "62",
                            "price": "70275",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "ff71dfc4-551a-44e1-a09d-52a7c3c9d030",
                            "order_uuid": "b5aff589-dc86-4fdd-b830-c64cf3f77e59",
                            "item_name": "Item7",
                            "item_quantity": "92",
                            "price": "93473",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "94abc499-c312-4183-a1a1-2d5acc516569",
            "first_name": "Amber",
            "last_name": "Monarrez",
            "company_name": "Branford Wire & Mfg Co",
            "address": "14288 Foster Ave #4121",
            "city": "Jenkintown",
            "county": "Montgomery",
            "state": "PA",
            "zip": 19046,
            "phone1": "215-934-8655",
            "phone2": "215-329-6386",
            "email": "amber_monarrez@monarrez.org",
            "web": "http://www.branfordwiremfgco.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "afd1b6d3-9ec3-467c-8330-d14f3b18bf8b",
                    "customer_uuid": "94abc499-c312-4183-a1a1-2d5acc516569",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "45",
                    "total_amount": "14375",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "86bcbb4e-d251-4a19-b626-c69721c79f19",
                            "order_uuid": "afd1b6d3-9ec3-467c-8330-d14f3b18bf8b",
                            "item_name": "Item7",
                            "item_quantity": "87",
                            "price": "48955",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "b9862c63-5381-422a-8a5b-d5bf6cb59de4",
                            "order_uuid": "afd1b6d3-9ec3-467c-8330-d14f3b18bf8b",
                            "item_name": "Item10",
                            "item_quantity": "98",
                            "price": "8262",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "962c3ceb-e3b0-4e9a-b329-a73ecd8b00a6",
            "first_name": "Mattie",
            "last_name": "Poquette",
            "company_name": "Century Communications",
            "address": "73 State Road 434 E",
            "city": "Phoenix",
            "county": "Maricopa",
            "state": "AZ",
            "zip": 85013,
            "phone1": "602-277-4385",
            "phone2": "602-953-6360",
            "email": "mattie@aol.com",
            "web": "http://www.centurycommunications.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "943db6d7-4f72-4900-84b3-dd854f0bc33d",
                    "customer_uuid": "962c3ceb-e3b0-4e9a-b329-a73ecd8b00a6",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "14",
                    "total_amount": "3324",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "6191a115-e2df-4254-ae09-68a8617848be",
                            "order_uuid": "943db6d7-4f72-4900-84b3-dd854f0bc33d",
                            "item_name": "Item1",
                            "item_quantity": "38",
                            "price": "9846",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "9f13cc56-cf8c-47da-aa75-ce0fa452dd3b",
                            "order_uuid": "943db6d7-4f72-4900-84b3-dd854f0bc33d",
                            "item_name": "Item8",
                            "item_quantity": "87",
                            "price": "4731",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "9b5015b1-0eb4-49b2-91cb-9b7b965108c2",
            "first_name": "Delisa",
            "last_name": "Crupi",
            "company_name": "Wood & Whitacre Contractors",
            "address": "47565 W Grand Ave",
            "city": "Newark",
            "county": "Essex",
            "state": "NJ",
            "zip": 7105,
            "phone1": "973-354-2040",
            "phone2": "973-847-9611",
            "email": "delisa.crupi@crupi.com",
            "web": "http://www.woodwhitacrecontractors.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "92303dc2-cefe-4470-b0bb-a44f1f8751db",
                    "customer_uuid": "9b5015b1-0eb4-49b2-91cb-9b7b965108c2",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "17",
                    "total_amount": "87847",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "688c3501-225d-4e89-9591-f4f7969b7c9e",
                            "order_uuid": "92303dc2-cefe-4470-b0bb-a44f1f8751db",
                            "item_name": "Item7",
                            "item_quantity": "52",
                            "price": "22716",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "692fedce-4589-4081-adb2-37d0ce7d9b40",
                            "order_uuid": "92303dc2-cefe-4470-b0bb-a44f1f8751db",
                            "item_name": "Item8",
                            "item_quantity": "96",
                            "price": "28032",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "9ec7a182-33db-4539-87eb-785222eb1db7",
            "first_name": "Lai",
            "last_name": "Gato",
            "company_name": "Fligg, Kenneth I Jr",
            "address": "37 Alabama Ave",
            "city": "Evanston",
            "county": "Cook",
            "state": "IL",
            "zip": 60201,
            "phone1": "847-728-7286",
            "phone2": "847-957-4614",
            "email": "lai.gato@gato.org",
            "web": "http://www.fliggkennethijr.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "bf0bce7c-873b-488d-a529-ccdfad6d8c1a",
                    "customer_uuid": "9ec7a182-33db-4539-87eb-785222eb1db7",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "86",
                    "total_amount": "60182",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "288d033a-bb52-4756-baa0-e80ee8c797a3",
                            "order_uuid": "bf0bce7c-873b-488d-a529-ccdfad6d8c1a",
                            "item_name": "Item9",
                            "item_quantity": "97",
                            "price": "25239",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "5908a835-f0cb-4843-8fed-0edd0cb0b3bf",
                            "order_uuid": "bf0bce7c-873b-488d-a529-ccdfad6d8c1a",
                            "item_name": "Item8",
                            "item_quantity": "84",
                            "price": "31921",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "9fd5424b-55c9-4e81-9c3b-9adb1bc4d1f9",
            "first_name": "Bette",
            "last_name": "Nicka",
            "company_name": "Sport En Art",
            "address": "6 S 33rd St",
            "city": "Aston",
            "county": "Delaware",
            "state": "PA",
            "zip": 19014,
            "phone1": "610-545-3615",
            "phone2": "610-492-4643",
            "email": "bette_nicka@cox.net",
            "web": "http://www.sportenart.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "9cc2d4b0-5ca7-4771-8d40-d8c2bf8241c9",
                    "customer_uuid": "9fd5424b-55c9-4e81-9c3b-9adb1bc4d1f9",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "93",
                    "total_amount": "34990",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "a97e2293-2400-4c82-afe9-8f3d831cf2a0",
                            "order_uuid": "9cc2d4b0-5ca7-4771-8d40-d8c2bf8241c9",
                            "item_name": "Item3",
                            "item_quantity": "17",
                            "price": "62693",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "f70be4f2-21c0-45a1-a1f5-64d2699f8f46",
                            "order_uuid": "9cc2d4b0-5ca7-4771-8d40-d8c2bf8241c9",
                            "item_name": "Item1",
                            "item_quantity": "86",
                            "price": "11138",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "a075812f-59f1-4a1b-baf7-9dc531e614e1",
            "first_name": "Ammie",
            "last_name": "Corrio",
            "company_name": "Moskowitz, Barry S",
            "address": "74874 Atlantic Ave",
            "city": "Columbus",
            "county": "Franklin",
            "state": "OH",
            "zip": 43215,
            "phone1": "614-801-9788",
            "phone2": "614-648-3265",
            "email": "ammie@corrio.com",
            "web": "http://www.moskowitzbarrys.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "d9fc2af8-09bf-4b23-8f1d-30d4d66f7388",
                    "customer_uuid": "a075812f-59f1-4a1b-baf7-9dc531e614e1",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "27",
                    "total_amount": "74248",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "2093550f-7dd5-4877-95d0-2d8f9e0c3d12",
                            "order_uuid": "d9fc2af8-09bf-4b23-8f1d-30d4d66f7388",
                            "item_name": "Item2",
                            "item_quantity": "64",
                            "price": "78249",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "8078643d-b59f-4d02-86ba-e5da5835db33",
                            "order_uuid": "d9fc2af8-09bf-4b23-8f1d-30d4d66f7388",
                            "item_name": "Item10",
                            "item_quantity": "79",
                            "price": "90141",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "a0915d18-a31d-467c-8870-1a9ad8bb8e44",
            "first_name": "Simona",
            "last_name": "Morasca",
            "company_name": "Chapman, Ross E Esq",
            "address": "3 Mcauley Dr",
            "city": "Ashland",
            "county": "Ashland",
            "state": "OH",
            "zip": 44805,
            "phone1": "419-503-2484",
            "phone2": "419-800-6759",
            "email": "simona@morasca.com",
            "web": "http://www.chapmanrosseesq.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "dd174eec-8fdf-41a2-9f11-5e5577ca0cf2",
                    "customer_uuid": "a0915d18-a31d-467c-8870-1a9ad8bb8e44",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "90",
                    "total_amount": "21261",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "103cce97-e897-48cc-ba40-72a83c4910fd",
                            "order_uuid": "dd174eec-8fdf-41a2-9f11-5e5577ca0cf2",
                            "item_name": "Item9",
                            "item_quantity": "31",
                            "price": "61750",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "f75d2d21-c6ab-47b5-9305-3e35b1768f0b",
                            "order_uuid": "dd174eec-8fdf-41a2-9f11-5e5577ca0cf2",
                            "item_name": "Item1",
                            "item_quantity": "80",
                            "price": "9857",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "a44d5ca7-be0f-4d57-aa5c-2fdc023be7a8",
            "first_name": "Alishia",
            "last_name": "Sergi",
            "company_name": "Milford Enterprises Inc",
            "address": "2742 Distribution Way",
            "city": "New York",
            "county": "New York",
            "state": "NY",
            "zip": 10025,
            "phone1": "212-860-1579",
            "phone2": "212-753-2740",
            "email": "asergi@gmail.com",
            "web": "http://www.milfordenterprisesinc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "ae9966b2-6203-4637-9ba5-71c53ae3d62a",
                    "customer_uuid": "a44d5ca7-be0f-4d57-aa5c-2fdc023be7a8",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "95",
                    "total_amount": "89779",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "5d048fcd-0e8b-40c0-8b69-860414833866",
                            "order_uuid": "ae9966b2-6203-4637-9ba5-71c53ae3d62a",
                            "item_name": "Item9",
                            "item_quantity": "79",
                            "price": "3095",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "e3261651-535a-43f0-b575-1048bbc7e49c",
                            "order_uuid": "ae9966b2-6203-4637-9ba5-71c53ae3d62a",
                            "item_name": "Item1",
                            "item_quantity": "38",
                            "price": "69002",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "a4a61e76-40c2-4e39-bee7-d843ee7097ed",
            "first_name": "Emerson",
            "last_name": "Bowley",
            "company_name": "Knights Inn",
            "address": "762 S Main St",
            "city": "Madison",
            "county": "Dane",
            "state": "WI",
            "zip": 53711,
            "phone1": "608-336-7444",
            "phone2": "608-658-7940",
            "email": "emerson.bowley@bowley.org",
            "web": "http://www.knightsinn.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "0bebe05f-b1d3-482b-b6f0-08f4d3046482",
                    "customer_uuid": "a4a61e76-40c2-4e39-bee7-d843ee7097ed",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "96",
                    "total_amount": "46683",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "539a27d8-cf7c-4739-ad24-0a7cdb1ad02e",
                            "order_uuid": "0bebe05f-b1d3-482b-b6f0-08f4d3046482",
                            "item_name": "Item10",
                            "item_quantity": "50",
                            "price": "21246",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "ba04c86a-190e-4f4e-aecb-aa002789780b",
                            "order_uuid": "0bebe05f-b1d3-482b-b6f0-08f4d3046482",
                            "item_name": "Item10",
                            "item_quantity": "86",
                            "price": "88743",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "a72e55e9-9917-4b71-aa8c-6371eb1cd5bc",
            "first_name": "Jose",
            "last_name": "Stockham",
            "company_name": "Tri State Refueler Co",
            "address": "128 Bransten Rd",
            "city": "New York",
            "county": "New York",
            "state": "NY",
            "zip": 10011,
            "phone1": "212-675-8570",
            "phone2": "212-569-4233",
            "email": "jose@yahoo.com",
            "web": "http://www.tristaterefuelerco.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "219d91e8-853d-4d2e-82ec-0b9a7671ecb0",
                    "customer_uuid": "a72e55e9-9917-4b71-aa8c-6371eb1cd5bc",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "71",
                    "total_amount": "39090",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "600a10ff-eb64-4752-8760-345f0bb0cf75",
                            "order_uuid": "219d91e8-853d-4d2e-82ec-0b9a7671ecb0",
                            "item_name": "Item6",
                            "item_quantity": "11",
                            "price": "84028",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "b1e853ea-aeba-43ea-9477-67728f715426",
                            "order_uuid": "219d91e8-853d-4d2e-82ec-0b9a7671ecb0",
                            "item_name": "Item4",
                            "item_quantity": "61",
                            "price": "26503",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "a7f200fc-b215-4665-a980-19ac35c00746",
            "first_name": "Penney",
            "last_name": "Weight",
            "company_name": "Hawaiian King Hotel",
            "address": "18 Fountain St",
            "city": "Anchorage",
            "county": "Anchorage",
            "state": "AK",
            "zip": 99515,
            "phone1": "907-797-9628",
            "phone2": "907-873-2882",
            "email": "penney_weight@aol.com",
            "web": "http://www.hawaiiankinghotel.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "e8f49afe-f189-45ad-859e-3a503d894d1e",
                    "customer_uuid": "a7f200fc-b215-4665-a980-19ac35c00746",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "87",
                    "total_amount": "42643",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "29f7a812-8357-406c-a6d4-0dce8992d067",
                            "order_uuid": "e8f49afe-f189-45ad-859e-3a503d894d1e",
                            "item_name": "Item1",
                            "item_quantity": "97",
                            "price": "90809",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "b2dd4319-bcc9-4b1b-a27b-24a301bb096c",
                            "order_uuid": "e8f49afe-f189-45ad-859e-3a503d894d1e",
                            "item_name": "Item3",
                            "item_quantity": "98",
                            "price": "45882",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "a85b22cd-f5cb-4c11-9ade-60874f40d2f5",
            "first_name": "Cory",
            "last_name": "Gibes",
            "company_name": "Chinese Translation Resources",
            "address": "83649 W Belmont Ave",
            "city": "San Gabriel",
            "county": "Los Angeles",
            "state": "CA",
            "zip": 91776,
            "phone1": "626-572-1096",
            "phone2": "626-696-2777",
            "email": "cory.gibes@gmail.com",
            "web": "http://www.chinesetranslationresources.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "888346a9-a399-43da-a15f-88c986d4e656",
                    "customer_uuid": "a85b22cd-f5cb-4c11-9ade-60874f40d2f5",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "73",
                    "total_amount": "81957",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "5a65f1f5-0c89-4a32-84a8-13cea651ee3a",
                            "order_uuid": "888346a9-a399-43da-a15f-88c986d4e656",
                            "item_name": "Item4",
                            "item_quantity": "23",
                            "price": "83606",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "87bd7136-c203-422b-a97c-5a3cbbd48550",
                            "order_uuid": "888346a9-a399-43da-a15f-88c986d4e656",
                            "item_name": "Item5",
                            "item_quantity": "52",
                            "price": "49774",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "ab5496dd-064b-42b3-8314-7efef433380c",
            "first_name": "Bernardo",
            "last_name": "Figeroa",
            "company_name": "Clark, Richard Cpa",
            "address": "386 9th Ave N",
            "city": "Conroe",
            "county": "Montgomery",
            "state": "TX",
            "zip": 77301,
            "phone1": "936-336-3951",
            "phone2": "936-597-3614",
            "email": "bfigeroa@aol.com",
            "web": "http://www.clarkrichardcpa.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "2b9d33d6-d842-4d75-87e7-fda2e1b5903f",
                    "customer_uuid": "ab5496dd-064b-42b3-8314-7efef433380c",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "89",
                    "total_amount": "10079",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "15d65fd6-b08b-4ab6-8307-4994463548dc",
                            "order_uuid": "2b9d33d6-d842-4d75-87e7-fda2e1b5903f",
                            "item_name": "Item2",
                            "item_quantity": "38",
                            "price": "2735",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "b4ac01c9-e990-4e9a-9a76-f922609d8520",
                            "order_uuid": "2b9d33d6-d842-4d75-87e7-fda2e1b5903f",
                            "item_name": "Item3",
                            "item_quantity": "17",
                            "price": "26498",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "b27d7008-aefa-42da-88df-fd0435cbfbb9",
            "first_name": "Lettie",
            "last_name": "Isenhower",
            "company_name": "Conte, Christopher A Esq",
            "address": "70 W Main St",
            "city": "Beachwood",
            "county": "Cuyahoga",
            "state": "OH",
            "zip": 44122,
            "phone1": "216-657-7668",
            "phone2": "216-733-8494",
            "email": "lettie_isenhower@yahoo.com",
            "web": "http://www.contechristopheraesq.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "c437df69-8c77-47f0-a3d8-65d61e3f22fc",
                    "customer_uuid": "b27d7008-aefa-42da-88df-fd0435cbfbb9",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "46",
                    "total_amount": "74472",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "50cc402c-55fa-44f5-868f-9f90042e89ad",
                            "order_uuid": "c437df69-8c77-47f0-a3d8-65d61e3f22fc",
                            "item_name": "Item8",
                            "item_quantity": "65",
                            "price": "83856",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "6247c87e-f290-4b6d-8fa0-8edb6f5de0f6",
                            "order_uuid": "c437df69-8c77-47f0-a3d8-65d61e3f22fc",
                            "item_name": "Item5",
                            "item_quantity": "29",
                            "price": "99222",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "b2f63cda-cef1-44b6-a79b-ca376dd97c63",
            "first_name": "Graciela",
            "last_name": "Ruta",
            "company_name": "Buckley Miller & Wright",
            "address": "98 Connecticut Ave Nw",
            "city": "Chagrin Falls",
            "county": "Geauga",
            "state": "OH",
            "zip": 44023,
            "phone1": "440-780-8425",
            "phone2": "440-579-7763",
            "email": "gruta@cox.net",
            "web": "http://www.buckleymillerwright.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "90d39ca2-897b-482b-8bee-9293f77cb028",
                    "customer_uuid": "b2f63cda-cef1-44b6-a79b-ca376dd97c63",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "30",
                    "total_amount": "24050",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "2e3a0ad2-4db6-47e7-be71-f59e68418193",
                            "order_uuid": "90d39ca2-897b-482b-8bee-9293f77cb028",
                            "item_name": "Item6",
                            "item_quantity": "63",
                            "price": "83154",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "c69488c7-25d3-46af-8960-08f32fa75f80",
                            "order_uuid": "90d39ca2-897b-482b-8bee-9293f77cb028",
                            "item_name": "Item8",
                            "item_quantity": "99",
                            "price": "33481",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "b602b32c-db3f-47e2-896e-10fb35c1b7bb",
            "first_name": "Tamar",
            "last_name": "Hoogland",
            "company_name": "A K Construction Co",
            "address": "2737 Pistorio Rd #9230",
            "city": "London",
            "county": "Madison",
            "state": "OH",
            "zip": 43140,
            "phone1": "740-343-8575",
            "phone2": "740-526-5410",
            "email": "tamar@hotmail.com",
            "web": "http://www.akconstructionco.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "566f36b4-d5c3-4eba-96a4-4ba5e82f4bfd",
                    "customer_uuid": "b602b32c-db3f-47e2-896e-10fb35c1b7bb",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "25",
                    "total_amount": "77046",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "0a715f27-2a2e-4e4d-a10e-207bc09282be",
                            "order_uuid": "566f36b4-d5c3-4eba-96a4-4ba5e82f4bfd",
                            "item_name": "Item3",
                            "item_quantity": "53",
                            "price": "3630",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "bf68574d-5d27-4bb4-8a1e-786b2aad75f0",
                            "order_uuid": "566f36b4-d5c3-4eba-96a4-4ba5e82f4bfd",
                            "item_name": "Item5",
                            "item_quantity": "84",
                            "price": "51408",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "b813c63d-db39-4456-8492-5c583cdbe431",
            "first_name": "Donette",
            "last_name": "Foller",
            "company_name": "Printing Dimensions",
            "address": "34 Center St",
            "city": "Hamilton",
            "county": "Butler",
            "state": "OH",
            "zip": 45011,
            "phone1": "513-570-1893",
            "phone2": "513-549-4561",
            "email": "donette.foller@cox.net",
            "web": "http://www.printingdimensions.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "15b8ff39-f0d4-47a2-a853-356679a62338",
                    "customer_uuid": "b813c63d-db39-4456-8492-5c583cdbe431",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "26",
                    "total_amount": "15134",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "092d6929-8df7-4d86-892e-a70553f7a2e7",
                            "order_uuid": "15b8ff39-f0d4-47a2-a853-356679a62338",
                            "item_name": "Item4",
                            "item_quantity": "71",
                            "price": "6340",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "124e1af2-3c82-470f-b972-892021325339",
                            "order_uuid": "15b8ff39-f0d4-47a2-a853-356679a62338",
                            "item_name": "Item7",
                            "item_quantity": "69",
                            "price": "38088",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "bd133e80-64b9-42d7-afb2-738ca22bd24c",
            "first_name": "Vallie",
            "last_name": "Mondella",
            "company_name": "Private Properties",
            "address": "74 W College St",
            "city": "Boise",
            "county": "Ada",
            "state": "ID",
            "zip": 83707,
            "phone1": "208-862-5339",
            "phone2": "208-737-8439",
            "email": "vmondella@mondella.com",
            "web": "http://www.privateproperties.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "b3ddd517-0d2d-4b2f-a2bc-30214f4d5819",
                    "customer_uuid": "bd133e80-64b9-42d7-afb2-738ca22bd24c",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "3",
                    "total_amount": "86482",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "ad2728b4-1093-4c57-8ce7-dd66aab2b76c",
                            "order_uuid": "b3ddd517-0d2d-4b2f-a2bc-30214f4d5819",
                            "item_name": "Item9",
                            "item_quantity": "35",
                            "price": "25074",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "ec85e6af-bf2a-470f-8d58-be7bc0f76104",
                            "order_uuid": "b3ddd517-0d2d-4b2f-a2bc-30214f4d5819",
                            "item_name": "Item1",
                            "item_quantity": "72",
                            "price": "6342",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "bee79a24-a6d4-440d-af64-1ec32473312d",
            "first_name": "Carmelina",
            "last_name": "Lindall",
            "company_name": "George Jessop Carter Jewelers",
            "address": "2664 Lewis Rd",
            "city": "Littleton",
            "county": "Douglas",
            "state": "CO",
            "zip": 80126,
            "phone1": "303-724-7371",
            "phone2": "303-874-5160",
            "email": "carmelina_lindall@lindall.com",
            "web": "http://www.georgejessopcarterjewelers.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "b69bf740-2e8e-49e0-aaa6-1b00993005d5",
                    "customer_uuid": "bee79a24-a6d4-440d-af64-1ec32473312d",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "41",
                    "total_amount": "94380",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "344180ee-a974-42f8-9b61-eaf3e3665517",
                            "order_uuid": "b69bf740-2e8e-49e0-aaa6-1b00993005d5",
                            "item_name": "Item3",
                            "item_quantity": "87",
                            "price": "78594",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "a3968658-bd2b-4bbc-887a-51ab6d64e508",
                            "order_uuid": "b69bf740-2e8e-49e0-aaa6-1b00993005d5",
                            "item_name": "Item1",
                            "item_quantity": "55",
                            "price": "79181",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "c1942c68-a459-44e2-82c7-91cd72553187",
            "first_name": "Bobbye",
            "last_name": "Rhym",
            "company_name": "Smits, Patricia Garity",
            "address": "30 W 80th St #1995",
            "city": "San Carlos",
            "county": "San Mateo",
            "state": "CA",
            "zip": 94070,
            "phone1": "650-528-5783",
            "phone2": "650-811-9032",
            "email": "brhym@rhym.com",
            "web": "http://www.smitspatriciagarity.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "6ccf828b-c44b-4d14-93c4-46f8e2d484a1",
                    "customer_uuid": "c1942c68-a459-44e2-82c7-91cd72553187",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "13",
                    "total_amount": "82346",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "2aa830e9-4bac-41bf-bcfd-35a400334b35",
                            "order_uuid": "6ccf828b-c44b-4d14-93c4-46f8e2d484a1",
                            "item_name": "Item1",
                            "item_quantity": "97",
                            "price": "39972",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "a572b84e-2f39-47eb-b9aa-32b88be8c64b",
                            "order_uuid": "6ccf828b-c44b-4d14-93c4-46f8e2d484a1",
                            "item_name": "Item2",
                            "item_quantity": "22",
                            "price": "14521",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "c8ba110a-1595-4d50-b53c-3666bf6fd81a",
            "first_name": "Mitsue",
            "last_name": "Tollner",
            "company_name": "Morlong Associates",
            "address": "7 Eads St",
            "city": "Chicago",
            "county": "Cook",
            "state": "IL",
            "zip": 60632,
            "phone1": "773-573-6914",
            "phone2": "773-924-8565",
            "email": "mitsue_tollner@yahoo.com",
            "web": "http://www.morlongassociates.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "0ffdb86b-11ad-4f97-96f0-ff7a5aeeff81",
                    "customer_uuid": "c8ba110a-1595-4d50-b53c-3666bf6fd81a",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "66",
                    "total_amount": "10665",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "f8104350-606f-444c-87ea-c2ed3e9c4205",
                            "order_uuid": "0ffdb86b-11ad-4f97-96f0-ff7a5aeeff81",
                            "item_name": "Item3",
                            "item_quantity": "36",
                            "price": "25006",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "f872248e-2e8f-4e9b-91c9-265293e08fe7",
                            "order_uuid": "0ffdb86b-11ad-4f97-96f0-ff7a5aeeff81",
                            "item_name": "Item5",
                            "item_quantity": "35",
                            "price": "76293",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "cbb21dea-9ca0-45b7-b905-938f86faf303",
            "first_name": "James",
            "last_name": "Butt",
            "company_name": "Benton, John B Jr",
            "address": "6649 N Blue Gum St",
            "city": "New Orleans",
            "county": "Orleans",
            "state": "LA",
            "zip": 70116,
            "phone1": "504-621-8927",
            "phone2": "504-845-1427",
            "email": "jbutt@gmail.com",
            "web": "http://www.bentonjohnbjr.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "fe048f88-7b34-410d-b4ba-e38e0d175c56",
                    "customer_uuid": "cbb21dea-9ca0-45b7-b905-938f86faf303",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "53",
                    "total_amount": "68593",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "22a15e79-e343-4e82-8fff-9b6d8d947e9d",
                            "order_uuid": "fe048f88-7b34-410d-b4ba-e38e0d175c56",
                            "item_name": "Item4",
                            "item_quantity": "61",
                            "price": "95006",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "b29f5c4a-a0d0-4d10-9039-40513ef36202",
                            "order_uuid": "fe048f88-7b34-410d-b4ba-e38e0d175c56",
                            "item_name": "Item1",
                            "item_quantity": "13",
                            "price": "65808",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "cc28fda9-d339-4310-bd10-9f69b139d34a",
            "first_name": "Natalie",
            "last_name": "Fern",
            "company_name": "Kelly, Charles G Esq",
            "address": "7140 University Ave",
            "city": "Rock Springs",
            "county": "Sweetwater",
            "state": "WY",
            "zip": 82901,
            "phone1": "307-704-8713",
            "phone2": "307-279-3793",
            "email": "natalie.fern@hotmail.com",
            "web": "http://www.kellycharlesgesq.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "20033df5-4b06-4fbd-b545-44bc40b27719",
                    "customer_uuid": "cc28fda9-d339-4310-bd10-9f69b139d34a",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "51",
                    "total_amount": "51271",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "4a4a805b-7eff-4599-842b-ae6727cade7e",
                            "order_uuid": "20033df5-4b06-4fbd-b545-44bc40b27719",
                            "item_name": "Item8",
                            "item_quantity": "100",
                            "price": "74824",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "c592afcd-4668-4f2f-a22b-6ef215201983",
                            "order_uuid": "20033df5-4b06-4fbd-b545-44bc40b27719",
                            "item_name": "Item4",
                            "item_quantity": "55",
                            "price": "27405",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "cc42d8d9-1b75-4e6c-a1a4-5f973002658b",
            "first_name": "Ilene",
            "last_name": "Eroman",
            "company_name": "Robinson, William J Esq",
            "address": "2853 S Central Expy",
            "city": "Glen Burnie",
            "county": "Anne Arundel",
            "state": "MD",
            "zip": 21061,
            "phone1": "410-914-9018",
            "phone2": "410-937-4543",
            "email": "ilene.eroman@hotmail.com",
            "web": "http://www.robinsonwilliamjesq.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "89791921-2900-45f9-986a-de6bf0915d86",
                    "customer_uuid": "cc42d8d9-1b75-4e6c-a1a4-5f973002658b",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "98",
                    "total_amount": "91693",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "186aa996-6904-4d8b-b1cb-17d851cfa745",
                            "order_uuid": "89791921-2900-45f9-986a-de6bf0915d86",
                            "item_name": "Item4",
                            "item_quantity": "43",
                            "price": "12966",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "1ade0a7f-d1a7-4c6b-95d2-c27ee23eba28",
                            "order_uuid": "89791921-2900-45f9-986a-de6bf0915d86",
                            "item_name": "Item2",
                            "item_quantity": "84",
                            "price": "70749",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "d0cc63c3-3a6b-49a7-b7dd-383cf64cf3be",
            "first_name": "Stephen",
            "last_name": "Emigh",
            "company_name": "Sharp, J Daniel Esq",
            "address": "3777 E Richmond St #900",
            "city": "Akron",
            "county": "Summit",
            "state": "OH",
            "zip": 44302,
            "phone1": "330-537-5358",
            "phone2": "330-700-2312",
            "email": "stephen_emigh@hotmail.com",
            "web": "http://www.sharpjdanielesq.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "7fb4fd5d-347d-4e08-95ce-aaa0387a9664",
                    "customer_uuid": "d0cc63c3-3a6b-49a7-b7dd-383cf64cf3be",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "61",
                    "total_amount": "97826",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "3d71a230-b05b-4edd-a29d-fa0be8cc4827",
                            "order_uuid": "7fb4fd5d-347d-4e08-95ce-aaa0387a9664",
                            "item_name": "Item1",
                            "item_quantity": "29",
                            "price": "59953",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "5d3d010a-585f-41b5-ba45-ec7eadfabf46",
                            "order_uuid": "7fb4fd5d-347d-4e08-95ce-aaa0387a9664",
                            "item_name": "Item7",
                            "item_quantity": "18",
                            "price": "95980",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "d3de3566-fe37-4faa-aee5-98c52791e86c",
            "first_name": "Willow",
            "last_name": "Kusko",
            "company_name": "U Pull It",
            "address": "90991 Thorburn Ave",
            "city": "New York",
            "county": "New York",
            "state": "NY",
            "zip": 10011,
            "phone1": "212-582-4976",
            "phone2": "212-934-5167",
            "email": "wkusko@yahoo.com",
            "web": "http://www.upullit.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "66320225-9aa1-4cc6-a1f6-6250472cfb4b",
                    "customer_uuid": "d3de3566-fe37-4faa-aee5-98c52791e86c",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "32",
                    "total_amount": "9164",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "650a340c-d55b-4d11-a67f-763f8969a7bc",
                            "order_uuid": "66320225-9aa1-4cc6-a1f6-6250472cfb4b",
                            "item_name": "Item4",
                            "item_quantity": "14",
                            "price": "99954",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "cea55a40-0154-47c0-83f5-c041044a589a",
                            "order_uuid": "66320225-9aa1-4cc6-a1f6-6250472cfb4b",
                            "item_name": "Item6",
                            "item_quantity": "94",
                            "price": "84994",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "d7503cba-db92-4c5c-9bf6-b7657094e342",
            "first_name": "Gladys",
            "last_name": "Rim",
            "company_name": "T M Byxbee Company Pc",
            "address": "322 New Horizon Blvd",
            "city": "Milwaukee",
            "county": "Milwaukee",
            "state": "WI",
            "zip": 53207,
            "phone1": "414-661-9598",
            "phone2": "414-377-2880",
            "email": "gladys.rim@rim.org",
            "web": "http://www.tmbyxbeecompanypc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "6942160a-cea9-407e-982f-24cfc2472206",
                    "customer_uuid": "d7503cba-db92-4c5c-9bf6-b7657094e342",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "38",
                    "total_amount": "33217",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "022bdc67-a4ea-4619-bdd3-7a764d388d43",
                            "order_uuid": "6942160a-cea9-407e-982f-24cfc2472206",
                            "item_name": "Item8",
                            "item_quantity": "24",
                            "price": "68146",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "e0ea3855-34c4-4c83-aab6-b69b91a25ee3",
                            "order_uuid": "6942160a-cea9-407e-982f-24cfc2472206",
                            "item_name": "Item2",
                            "item_quantity": "47",
                            "price": "72279",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "d7f7b29a-58b1-407c-99d7-18c1d4b7a12d",
            "first_name": "Dominque",
            "last_name": "Dickerson",
            "company_name": "E A I Electronic Assocs Inc",
            "address": "69 Marquette Ave",
            "city": "Hayward",
            "county": "Alameda",
            "state": "CA",
            "zip": 94545,
            "phone1": "510-993-3758",
            "phone2": "510-901-7640",
            "email": "dominque.dickerson@dickerson.org",
            "web": "http://www.eaielectronicassocsinc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "e92ae641-b9f7-4135-8929-bdc56c2ef27d",
                    "customer_uuid": "d7f7b29a-58b1-407c-99d7-18c1d4b7a12d",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "22",
                    "total_amount": "99738",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "a595685a-6cc4-4101-aece-25ca784ddcdd",
                            "order_uuid": "e92ae641-b9f7-4135-8929-bdc56c2ef27d",
                            "item_name": "Item4",
                            "item_quantity": "60",
                            "price": "87751",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "e713d965-5d59-4a5f-9d56-94447de0e714",
                            "order_uuid": "e92ae641-b9f7-4135-8929-bdc56c2ef27d",
                            "item_name": "Item10",
                            "item_quantity": "38",
                            "price": "76425",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "d9019d74-3b7d-44e6-9b8b-4a22f942c06e",
            "first_name": "Kris",
            "last_name": "Marrier",
            "company_name": "King, Christopher A Esq",
            "address": "228 Runamuck Pl #2808",
            "city": "Baltimore",
            "county": "Baltimore City",
            "state": "MD",
            "zip": 21224,
            "phone1": "410-655-8723",
            "phone2": "410-804-4694",
            "email": "kris@gmail.com",
            "web": "http://www.kingchristopheraesq.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "91afbfef-8604-43c5-8526-ea6c8f8de184",
                    "customer_uuid": "d9019d74-3b7d-44e6-9b8b-4a22f942c06e",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "65",
                    "total_amount": "56458",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "8f6d0490-207b-4567-a099-c3379ed2132c",
                            "order_uuid": "91afbfef-8604-43c5-8526-ea6c8f8de184",
                            "item_name": "Item2",
                            "item_quantity": "22",
                            "price": "20484",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "db230d35-484d-47af-a328-c47ca112a998",
                            "order_uuid": "91afbfef-8604-43c5-8526-ea6c8f8de184",
                            "item_name": "Item8",
                            "item_quantity": "9",
                            "price": "80454",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "db9b93ac-a002-40f2-9632-e5c00e680139",
            "first_name": "Youlanda",
            "last_name": "Schemmer",
            "company_name": "Tri M Tool Inc",
            "address": "2881 Lewis Rd",
            "city": "Prineville",
            "county": "Crook",
            "state": "OR",
            "zip": 97754,
            "phone1": "541-548-8197",
            "phone2": "541-993-2611",
            "email": "youlanda@aol.com",
            "web": "http://www.trimtoolinc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "461e0ab4-240d-4685-847d-47073511d846",
                    "customer_uuid": "db9b93ac-a002-40f2-9632-e5c00e680139",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "19",
                    "total_amount": "89699",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "4493bf8e-057e-47a6-a499-7adfc7422531",
                            "order_uuid": "461e0ab4-240d-4685-847d-47073511d846",
                            "item_name": "Item1",
                            "item_quantity": "40",
                            "price": "63066",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "d6245a54-77a0-4c65-8ba9-d723d275cf2b",
                            "order_uuid": "461e0ab4-240d-4685-847d-47073511d846",
                            "item_name": "Item8",
                            "item_quantity": "49",
                            "price": "26690",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "dd9bba2c-70f6-46ab-be53-35b2eb5c1b00",
            "first_name": "Roxane",
            "last_name": "Campain",
            "company_name": "Rapid Trading Intl",
            "address": "1048 Main St",
            "city": "Fairbanks",
            "county": "Fairbanks North Star",
            "state": "AK",
            "zip": 99708,
            "phone1": "907-231-4722",
            "phone2": "907-335-6568",
            "email": "roxane@hotmail.com",
            "web": "http://www.rapidtradingintl.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "16ddb9ad-c903-4c38-a9ca-6a7459a2c1f0",
                    "customer_uuid": "dd9bba2c-70f6-46ab-be53-35b2eb5c1b00",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "21",
                    "total_amount": "53685",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "597817f1-dd1a-42a1-8714-35daa9aff40f",
                            "order_uuid": "16ddb9ad-c903-4c38-a9ca-6a7459a2c1f0",
                            "item_name": "Item5",
                            "item_quantity": "30",
                            "price": "50781",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "d83af1fd-d3fe-48ea-9fa0-3538c46d3e33",
                            "order_uuid": "16ddb9ad-c903-4c38-a9ca-6a7459a2c1f0",
                            "item_name": "Item1",
                            "item_quantity": "76",
                            "price": "35949",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "ddfdc406-b392-4eec-b8d6-4c67c5507404",
            "first_name": "Moon",
            "last_name": "Parlato",
            "company_name": "Ambelang, Jessica M Md",
            "address": "74989 Brandon St",
            "city": "Wellsville",
            "county": "Allegany",
            "state": "NY",
            "zip": 14895,
            "phone1": "585-866-8313",
            "phone2": "585-498-4278",
            "email": "moon@yahoo.com",
            "web": "http://www.ambelangjessicammd.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "3305831a-1a6c-44f4-8d6d-40d904589bd4",
                    "customer_uuid": "ddfdc406-b392-4eec-b8d6-4c67c5507404",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "12",
                    "total_amount": "62022",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "dbe1c15a-de43-4dc2-9753-01513072b57a",
                            "order_uuid": "3305831a-1a6c-44f4-8d6d-40d904589bd4",
                            "item_name": "Item5",
                            "item_quantity": "70",
                            "price": "11446",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "e0cd9411-98b9-4c6c-9c40-c9f915eef0c7",
                            "order_uuid": "3305831a-1a6c-44f4-8d6d-40d904589bd4",
                            "item_name": "Item5",
                            "item_quantity": "27",
                            "price": "20550",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "df5293e8-78bc-4db4-8ced-95fc123c4353",
            "first_name": "Willard",
            "last_name": "Kolmetz",
            "company_name": "Ingalls, Donald R Esq",
            "address": "618 W Yakima Ave",
            "city": "Irving",
            "county": "Dallas",
            "state": "TX",
            "zip": 75062,
            "phone1": "972-303-9197",
            "phone2": "972-896-4882",
            "email": "willard@hotmail.com",
            "web": "http://www.ingallsdonaldresq.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "77403173-e84c-4439-aa87-99b00169a331",
                    "customer_uuid": "df5293e8-78bc-4db4-8ced-95fc123c4353",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "92",
                    "total_amount": "86702",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "724d70e7-abcd-4ca1-bc80-3f8d6a45d3ee",
                            "order_uuid": "77403173-e84c-4439-aa87-99b00169a331",
                            "item_name": "Item8",
                            "item_quantity": "14",
                            "price": "54190",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "be3dfb04-e7b0-42d1-95e2-4d3a0df177a2",
                            "order_uuid": "77403173-e84c-4439-aa87-99b00169a331",
                            "item_name": "Item4",
                            "item_quantity": "37",
                            "price": "659",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "e14ab49a-7a71-44d2-afc7-b610fd0d3d6e",
            "first_name": "Kati",
            "last_name": "Rulapaugh",
            "company_name": "Eder Assocs Consltng Engrs Pc",
            "address": "6980 Dorsett Rd",
            "city": "Abilene",
            "county": "Dickinson",
            "state": "KS",
            "zip": 67410,
            "phone1": "785-463-7829",
            "phone2": "785-219-7724",
            "email": "kati.rulapaugh@hotmail.com",
            "web": "http://www.ederassocsconsltngengrspc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "0f5c6865-70c4-4447-b199-46988d4bb730",
                    "customer_uuid": "e14ab49a-7a71-44d2-afc7-b610fd0d3d6e",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "45",
                    "total_amount": "12290",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "dccf02b8-a5f9-47dc-938b-dfc049f1b535",
                            "order_uuid": "0f5c6865-70c4-4447-b199-46988d4bb730",
                            "item_name": "Item1",
                            "item_quantity": "94",
                            "price": "31103",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "dd40ee7d-5a40-4c86-8b46-30e9469e8053",
                            "order_uuid": "0f5c6865-70c4-4447-b199-46988d4bb730",
                            "item_name": "Item7",
                            "item_quantity": "59",
                            "price": "97595",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "e14ad45c-2b61-4c2f-b38b-2898c6311cc3",
            "first_name": "Erick",
            "last_name": "Ferencz",
            "company_name": "Cindy Turner Associates",
            "address": "20 S Babcock St",
            "city": "Fairbanks",
            "county": "Fairbanks North Star",
            "state": "AK",
            "zip": 99712,
            "phone1": "907-741-1044",
            "phone2": "907-227-6777",
            "email": "erick.ferencz@aol.com",
            "web": "http://www.cindyturnerassociates.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "13d87987-a4b1-443b-a084-cb30fc818a93",
                    "customer_uuid": "e14ad45c-2b61-4c2f-b38b-2898c6311cc3",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "94",
                    "total_amount": "72885",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "68ba84d2-9609-4d6c-a209-08cdb703b081",
                            "order_uuid": "13d87987-a4b1-443b-a084-cb30fc818a93",
                            "item_name": "Item10",
                            "item_quantity": "48",
                            "price": "9013",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "ae4477c7-d945-482d-ba2b-77f74664158e",
                            "order_uuid": "13d87987-a4b1-443b-a084-cb30fc818a93",
                            "item_name": "Item6",
                            "item_quantity": "69",
                            "price": "40289",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "e1c92c37-a456-4ef6-80ef-4d1a9ef40d4a",
            "first_name": "Veronika",
            "last_name": "Inouye",
            "company_name": "C 4 Network Inc",
            "address": "6 Greenleaf Ave",
            "city": "San Jose",
            "county": "Santa Clara",
            "state": "CA",
            "zip": 95111,
            "phone1": "408-540-1785",
            "phone2": "408-813-4592",
            "email": "vinouye@aol.com",
            "web": "http://www.cnetworkinc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "b476ac3d-32c4-482e-8ace-8afce0b3be53",
                    "customer_uuid": "e1c92c37-a456-4ef6-80ef-4d1a9ef40d4a",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "9",
                    "total_amount": "75662",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "4b37e008-907b-490b-88b0-9fd46c338139",
                            "order_uuid": "b476ac3d-32c4-482e-8ace-8afce0b3be53",
                            "item_name": "Item1",
                            "item_quantity": "35",
                            "price": "58609",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "c73c7668-5c87-494e-8235-e06169c821fe",
                            "order_uuid": "b476ac3d-32c4-482e-8ace-8afce0b3be53",
                            "item_name": "Item3",
                            "item_quantity": "88",
                            "price": "10930",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "e5a6ccf8-bd03-4a5c-ae04-76968cf17204",
            "first_name": "Elza",
            "last_name": "Lipke",
            "company_name": "Museum Of Science & Industry",
            "address": "6794 Lake Dr E",
            "city": "Newark",
            "county": "Essex",
            "state": "NJ",
            "zip": 7104,
            "phone1": "973-927-3447",
            "phone2": "973-796-3667",
            "email": "elza@yahoo.com",
            "web": "http://www.museumofscienceindustry.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "f474ba71-4d90-441e-8cab-e250dad035fe",
                    "customer_uuid": "e5a6ccf8-bd03-4a5c-ae04-76968cf17204",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "95",
                    "total_amount": "68025",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "7505e578-607e-4b44-9d04-c813c4f4a7f6",
                            "order_uuid": "f474ba71-4d90-441e-8cab-e250dad035fe",
                            "item_name": "Item6",
                            "item_quantity": "92",
                            "price": "66919",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "cdc8e185-793c-45d8-a43e-367ec791edb3",
                            "order_uuid": "f474ba71-4d90-441e-8cab-e250dad035fe",
                            "item_name": "Item10",
                            "item_quantity": "58",
                            "price": "47531",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "e7c97732-8551-4085-a02d-2f7217623f1d",
            "first_name": "Fatima",
            "last_name": "Saylors",
            "company_name": "Stanton, James D Esq",
            "address": "2 Lighthouse Ave",
            "city": "Hopkins",
            "county": "Hennepin",
            "state": "MN",
            "zip": 55343,
            "phone1": "952-768-2416",
            "phone2": "952-479-2375",
            "email": "fsaylors@saylors.org",
            "web": "http://www.stantonjamesdesq.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "b7b64647-b44f-4e48-b479-6bab8fa424de",
                    "customer_uuid": "e7c97732-8551-4085-a02d-2f7217623f1d",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "92",
                    "total_amount": "16751",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "06942266-fd81-47f7-8651-1d624902a581",
                            "order_uuid": "b7b64647-b44f-4e48-b479-6bab8fa424de",
                            "item_name": "Item10",
                            "item_quantity": "35",
                            "price": "35281",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "3ef34d30-ce01-4867-abd2-bcd13a06b40e",
                            "order_uuid": "b7b64647-b44f-4e48-b479-6bab8fa424de",
                            "item_name": "Item5",
                            "item_quantity": "7",
                            "price": "17004",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "e8f5784b-d90d-4036-b59a-6bdaa9b9403d",
            "first_name": "Delmy",
            "last_name": "Ahle",
            "company_name": "Wye Technologies Inc",
            "address": "65895 S 16th St",
            "city": "Providence",
            "county": "Providence",
            "state": "RI",
            "zip": 2909,
            "phone1": "401-458-2547",
            "phone2": "401-559-8961",
            "email": "delmy.ahle@hotmail.com",
            "web": "http://www.wyetechnologiesinc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "960c6ea3-f001-4848-92ea-e7b25a3361ed",
                    "customer_uuid": "e8f5784b-d90d-4036-b59a-6bdaa9b9403d",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "84",
                    "total_amount": "86960",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "2cfb2896-c42b-4226-ad28-216128e7de75",
                            "order_uuid": "960c6ea3-f001-4848-92ea-e7b25a3361ed",
                            "item_name": "Item7",
                            "item_quantity": "83",
                            "price": "45250",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "ee80b603-317a-4c98-bec2-18479ee6ca31",
                            "order_uuid": "960c6ea3-f001-4848-92ea-e7b25a3361ed",
                            "item_name": "Item10",
                            "item_quantity": "22",
                            "price": "91382",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "ebcfb17b-1f00-46d3-91e0-1c108150093d",
            "first_name": "Jina",
            "last_name": "Briddick",
            "company_name": "Grace Pastries Inc",
            "address": "38938 Park Blvd",
            "city": "Boston",
            "county": "Suffolk",
            "state": "MA",
            "zip": 2128,
            "phone1": "617-399-5124",
            "phone2": "617-997-5771",
            "email": "jina_briddick@briddick.com",
            "web": "http://www.gracepastriesinc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "de5a9c28-9005-4f4e-9525-18a0ca9c04ac",
                    "customer_uuid": "ebcfb17b-1f00-46d3-91e0-1c108150093d",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "97",
                    "total_amount": "85324",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "4f14eb4e-fb8b-4750-bad9-c8064e3b9435",
                            "order_uuid": "de5a9c28-9005-4f4e-9525-18a0ca9c04ac",
                            "item_name": "Item1",
                            "item_quantity": "67",
                            "price": "13451",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "7ce80cad-00b8-4c41-8a26-e3086c8aa354",
                            "order_uuid": "de5a9c28-9005-4f4e-9525-18a0ca9c04ac",
                            "item_name": "Item3",
                            "item_quantity": "8",
                            "price": "64526",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "ebefa9c9-7313-43ac-a0d2-438eb30f1efa",
            "first_name": "Sage",
            "last_name": "Wieser",
            "company_name": "Truhlar And Truhlar Attys",
            "address": "5 Boston Ave #88",
            "city": "Sioux Falls",
            "county": "Minnehaha",
            "state": "SD",
            "zip": 57105,
            "phone1": "605-414-2147",
            "phone2": "605-794-4895",
            "email": "sage_wieser@cox.net",
            "web": "http://www.truhlarandtruhlarattys.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "07756681-172c-41ca-ae91-6d9a878b04cd",
                    "customer_uuid": "ebefa9c9-7313-43ac-a0d2-438eb30f1efa",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "28",
                    "total_amount": "48937",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "afb84a39-8434-4197-addb-ae42cecdc697",
                            "order_uuid": "07756681-172c-41ca-ae91-6d9a878b04cd",
                            "item_name": "Item1",
                            "item_quantity": "55",
                            "price": "251",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "cc12c240-ceb1-4237-aa5b-79d69ce0102f",
                            "order_uuid": "07756681-172c-41ca-ae91-6d9a878b04cd",
                            "item_name": "Item1",
                            "item_quantity": "52",
                            "price": "76886",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "eed40887-06d6-4d1e-8a74-ebb603c23037",
            "first_name": "Brock",
            "last_name": "Bolognia",
            "company_name": "Orinda News",
            "address": "4486 W O St #1",
            "city": "New York",
            "county": "New York",
            "state": "NY",
            "zip": 10003,
            "phone1": "212-402-9216",
            "phone2": "212-617-5063",
            "email": "bbolognia@yahoo.com",
            "web": "http://www.orindanews.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "e52cbbbd-1067-4ffe-aa2e-8d82edd2dc74",
                    "customer_uuid": "eed40887-06d6-4d1e-8a74-ebb603c23037",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "56",
                    "total_amount": "61134",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "2350ae6b-beeb-4b5d-9768-73b912a88288",
                            "order_uuid": "e52cbbbd-1067-4ffe-aa2e-8d82edd2dc74",
                            "item_name": "Item9",
                            "item_quantity": "48",
                            "price": "41002",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "63ccc987-5ed6-4284-8604-ec540520a88d",
                            "order_uuid": "e52cbbbd-1067-4ffe-aa2e-8d82edd2dc74",
                            "item_name": "Item8",
                            "item_quantity": "58",
                            "price": "24543",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "f0051561-de26-4e3d-bad5-f4799999e6ff",
            "first_name": "Elly",
            "last_name": "Morocco",
            "company_name": "Killion Industries",
            "address": "7 W 32nd St",
            "city": "Erie",
            "county": "Erie",
            "state": "PA",
            "zip": 16502,
            "phone1": "814-393-5571",
            "phone2": "814-420-3553",
            "email": "elly_morocco@gmail.com",
            "web": "http://www.killionindustries.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "1899e35b-075b-4923-84be-79ec0973d4bf",
                    "customer_uuid": "f0051561-de26-4e3d-bad5-f4799999e6ff",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "35",
                    "total_amount": "10623",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "54e57676-0840-41b8-bad7-5dcf9354b7ee",
                            "order_uuid": "1899e35b-075b-4923-84be-79ec0973d4bf",
                            "item_name": "Item9",
                            "item_quantity": "62",
                            "price": "92449",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "71419edb-84de-4856-8fa7-a1a62a075d29",
                            "order_uuid": "1899e35b-075b-4923-84be-79ec0973d4bf",
                            "item_name": "Item1",
                            "item_quantity": "90",
                            "price": "90866",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "f1c6d92f-0787-4db6-bcc0-4387a30b1c67",
            "first_name": "Arlene",
            "last_name": "Klusman",
            "company_name": "Beck Horizon Builders",
            "address": "3 Secor Rd",
            "city": "New Orleans",
            "county": "Orleans",
            "state": "LA",
            "zip": 70112,
            "phone1": "504-710-5840",
            "phone2": "504-946-1807",
            "email": "arlene_klusman@gmail.com",
            "web": "http://www.beckhorizonbuilders.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "4d0b607b-ed3a-4f9b-ab64-98f6d227146f",
                    "customer_uuid": "f1c6d92f-0787-4db6-bcc0-4387a30b1c67",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "88",
                    "total_amount": "68689",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "1b6f117a-1142-4286-9961-0e0a5fda7b5d",
                            "order_uuid": "4d0b607b-ed3a-4f9b-ab64-98f6d227146f",
                            "item_name": "Item2",
                            "item_quantity": "20",
                            "price": "10353",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "71676a31-5a40-4eef-8f52-8415c9efc73d",
                            "order_uuid": "4d0b607b-ed3a-4f9b-ab64-98f6d227146f",
                            "item_name": "Item5",
                            "item_quantity": "41",
                            "price": "90407",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "f77251e2-ffe8-4bac-b251-ddede10012f1",
            "first_name": "Fletcher",
            "last_name": "Flosi",
            "company_name": "Post Box Services Plus",
            "address": "394 Manchester Blvd",
            "city": "Rockford",
            "county": "Winnebago",
            "state": "IL",
            "zip": 61109,
            "phone1": "815-828-2147",
            "phone2": "815-426-5657",
            "email": "fletcher.flosi@yahoo.com",
            "web": "http://www.postboxservicesplus.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "2b508f6e-211b-4d0d-bca3-34d3592f6282",
                    "customer_uuid": "f77251e2-ffe8-4bac-b251-ddede10012f1",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "75",
                    "total_amount": "80809",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "123177c1-e22a-466d-90a7-acfa0e00c345",
                            "order_uuid": "2b508f6e-211b-4d0d-bca3-34d3592f6282",
                            "item_name": "Item8",
                            "item_quantity": "31",
                            "price": "53743",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "1aca6186-f286-4555-bf25-d1d6198ac647",
                            "order_uuid": "2b508f6e-211b-4d0d-bca3-34d3592f6282",
                            "item_name": "Item4",
                            "item_quantity": "65",
                            "price": "33707",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "f85ded42-26fb-452f-8ead-455eef4245cc",
            "first_name": "Albina",
            "last_name": "Glick",
            "company_name": "Giampetro, Anthony D",
            "address": "4 Ralph Ct",
            "city": "Dunellen",
            "county": "Middlesex",
            "state": "NJ",
            "zip": 8812,
            "phone1": "732-924-7882",
            "phone2": "732-782-6701",
            "email": "albina@glick.com",
            "web": "http://www.giampetroanthonyd.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "4a14b917-e6b8-49bf-9e9b-a68a673b615f",
                    "customer_uuid": "f85ded42-26fb-452f-8ead-455eef4245cc",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "16",
                    "total_amount": "8616",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "1a12374a-922e-4705-9e7d-b7735ce2e203",
                            "order_uuid": "4a14b917-e6b8-49bf-9e9b-a68a673b615f",
                            "item_name": "Item10",
                            "item_quantity": "80",
                            "price": "52018",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "4883bd61-30a3-4154-a911-23364d4cddaf",
                            "order_uuid": "4a14b917-e6b8-49bf-9e9b-a68a673b615f",
                            "item_name": "Item10",
                            "item_quantity": "63",
                            "price": "50472",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "fc206efc-5be0-4fdf-8b3c-512a0cc455dd",
            "first_name": "Lenna",
            "last_name": "Paprocki",
            "company_name": "Feltz Printing Service",
            "address": "639 Main St",
            "city": "Anchorage",
            "county": "Anchorage",
            "state": "AK",
            "zip": 99501,
            "phone1": "907-385-4412",
            "phone2": "907-921-2010",
            "email": "lpaprocki@hotmail.com",
            "web": "http://www.feltzprintingservice.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "5d4ecc35-5202-498e-95be-1976da2c606f",
                    "customer_uuid": "fc206efc-5be0-4fdf-8b3c-512a0cc455dd",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "15",
                    "total_amount": "98914",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "7cb49965-c99c-4550-acc9-4eb406a2dbdd",
                            "order_uuid": "5d4ecc35-5202-498e-95be-1976da2c606f",
                            "item_name": "Item1",
                            "item_quantity": "79",
                            "price": "12785",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "df1dec82-e6ef-4149-8e25-492fd3a3b725",
                            "order_uuid": "5d4ecc35-5202-498e-95be-1976da2c606f",
                            "item_name": "Item8",
                            "item_quantity": "17",
                            "price": "42960",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "fd6ccd39-0d4c-4a8a-aa9f-a9064f26c552",
            "first_name": "Myra",
            "last_name": "Munns",
            "company_name": "Anker Law Office",
            "address": "461 Prospect Pl #316",
            "city": "Euless",
            "county": "Tarrant",
            "state": "TX",
            "zip": 76040,
            "phone1": "817-914-7518",
            "phone2": "817-451-3518",
            "email": "mmunns@cox.net",
            "web": "http://www.ankerlawoffice.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "4269c17c-e68c-48c6-b953-48421126f1fe",
                    "customer_uuid": "fd6ccd39-0d4c-4a8a-aa9f-a9064f26c552",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "85",
                    "total_amount": "82062",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "28d15645-1e35-44f6-b5e9-47daa1981682",
                            "order_uuid": "4269c17c-e68c-48c6-b953-48421126f1fe",
                            "item_name": "Item10",
                            "item_quantity": "88",
                            "price": "13487",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        },
                        {
                            "uuid": "c53d62a5-d97e-4bc5-9d75-a37f18d70c0e",
                            "order_uuid": "4269c17c-e68c-48c6-b953-48421126f1fe",
                            "item_name": "Item6",
                            "item_quantity": "90",
                            "price": "62881",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "ff40048f-a8ad-4f45-b9d9-f10bdc4b1b99",
            "first_name": "Cecily",
            "last_name": "Hollack",
            "company_name": "Arthur A Oliver & Son Inc",
            "address": "59 N Groesbeck Hwy",
            "city": "Austin",
            "county": "Travis",
            "state": "TX",
            "zip": 78731,
            "phone1": "512-486-3817",
            "phone2": "512-861-3814",
            "email": "cecily@hollack.org",
            "web": "http://www.arthuraoliversoninc.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "cdc6a057-7a41-42a8-830c-31540e5ca7d6",
                    "customer_uuid": "ff40048f-a8ad-4f45-b9d9-f10bdc4b1b99",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "41",
                    "total_amount": "10834",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "3de561ec-7d70-4aea-ae14-e35842ae41e8",
                            "order_uuid": "cdc6a057-7a41-42a8-830c-31540e5ca7d6",
                            "item_name": "Item7",
                            "item_quantity": "59",
                            "price": "58644",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "d6c5e748-5462-40ee-83d3-fe8bf9f91f0d",
                            "order_uuid": "cdc6a057-7a41-42a8-830c-31540e5ca7d6",
                            "item_name": "Item5",
                            "item_quantity": "10",
                            "price": "82235",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        },
        {
            "uuid": "ffc28933-7884-46ab-b2f6-5fbe553a5e12",
            "first_name": "Allene",
            "last_name": "Iturbide",
            "company_name": "Ledecky, David Esq",
            "address": "1 Central Ave",
            "city": "Stevens Point",
            "county": "Portage",
            "state": "WI",
            "zip": 54481,
            "phone1": "715-662-6764",
            "phone2": "715-530-9863",
            "email": "allene_iturbide@cox.net",
            "web": "http://www.ledeckydavidesq.com",
            "createdAt": "2023-09-17T14:07:24.000Z",
            "updatedAt": "2023-09-17T14:07:24.000Z",
            "CustomerOrders": [
                {
                    "uuid": "f865c33e-d708-44a7-8f49-57b0726e302e",
                    "customer_uuid": "ffc28933-7884-46ab-b2f6-5fbe553a5e12",
                    "shipping_address": "62021 Davis Wells,24569",
                    "billing_address": "62021 Davis Wells,24569",
                    "status": "SUCCESS",
                    "item_totals": "37",
                    "total_amount": "50950",
                    "createdAt": "2023-09-17T14:24:20.000Z",
                    "updatedAt": "2023-09-17T14:24:20.000Z",
                    "OrderItems": [
                        {
                            "uuid": "941203c3-3e39-42ee-ab81-6eb1a9bce576",
                            "order_uuid": "f865c33e-d708-44a7-8f49-57b0726e302e",
                            "item_name": "Item3",
                            "item_quantity": "38",
                            "price": "98372",
                            "createdAt": "2023-09-17T14:41:24.000Z",
                            "updatedAt": "2023-09-17T14:41:24.000Z"
                        },
                        {
                            "uuid": "a595742d-d5ca-44ee-bd48-7be499dabd5e",
                            "order_uuid": "f865c33e-d708-44a7-8f49-57b0726e302e",
                            "item_name": "Item10",
                            "item_quantity": "59",
                            "price": "81944",
                            "createdAt": "2023-09-17T14:41:20.000Z",
                            "updatedAt": "2023-09-17T14:41:20.000Z"
                        }
                    ]
                }
            ]
        }
    ]